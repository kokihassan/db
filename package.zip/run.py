#!/usr/bin/env python3
"""
Main entry point for DataBot
Runs both the Telegram bot and Admin Dashboard
"""
import os
import sys
import asyncio
import threading
from loguru import logger

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import settings
from database import init_db
from bot.services import openai_service, scraper_service


def run_bot():
    """Run the Telegram bot in a separate thread"""
    from bot.main import bot
    asyncio.run(bot.run())


def run_dashboard():
    """Run the Flask dashboard"""
    from dashboard.app import app
    app.run(host='0.0.0.0', port=5000, debug=settings.DEBUG)


def seed_default_data():
    """Seed default configuration data"""
    from database import db_session
    from database.models import Config, SubscriptionPlan

    logger.info("Checking for default data...")

    # Check if configs exist
    existing_configs = db_session.query(Config).count()
    if existing_configs == 0:
        logger.info("Seeding default configs...")
        from database.models import DEFAULT_CONFIGS
        for config_data in DEFAULT_CONFIGS:
            config = Config(**config_data)
            db_session.add(config)
        db_session.commit()
        logger.info("Default configs seeded.")

    # Check if plans exist
    existing_plans = db_session.query(SubscriptionPlan).count()
    if existing_plans == 0:
        logger.info("Seeding default subscription plans...")
        plans = [
            SubscriptionPlan(
                name_ar="البرونز",
                name_en="Bronze",
                description="باقة أساسية للمبتدئين",
                price_monthly=9.99,
                price_quarterly=24.99,
                price_yearly=89.99,
                features={
                    "items": [
                        "50 سكراب/يوم",
                        "1 وظيفة متزامنة",
                        "7 أيام تخزين البيانات",
                        "دعم عبر البريد"
                    ]
                },
                limits={
                    "scrapes_per_day": 50,
                    "concurrent_jobs": 1,
                    "data_retention_days": 7
                },
                display_order=1
            ),
            SubscriptionPlan(
                name_ar="الفضة",
                name_en="Silver",
                description="باقة متوسطة للمستخدمين المتوسطين",
                price_monthly=24.99,
                price_quarterly=59.99,
                price_yearly=199.99,
                features={
                    "items": [
                        "200 سكراب/يوم",
                        "5 وظائف متزامنة",
                        "30 يوم تخزين البيانات",
                        "دعم أولوية",
                        "API access"
                    ]
                },
                limits={
                    "scrapes_per_day": 200,
                    "concurrent_jobs": 5,
                    "data_retention_days": 30
                },
                display_order=2
            ),
            SubscriptionPlan(
                name_ar="الذهب",
                name_en="Gold",
                description="باقة متقدمة للمستخدمين المحترفين",
                price_monthly=49.99,
                price_quarterly=119.99,
                price_yearly=399.99,
                features={
                    "items": [
                        "سكرابات غير محدودة",
                        "وظائف غير محدودة",
                        "90 يوم تخزين البيانات",
                        "دعم 24/7",
                        "Custom selectors",
                        "Priority queue",
                        "Advanced analytics"
                    ]
                },
                limits={
                    "scrapes_per_day": 999999,
                    "concurrent_jobs": 999,
                    "data_retention_days": 90
                },
                display_order=3
            )
        ]
        for plan in plans:
            db_session.add(plan)
        db_session.commit()
        logger.info("Default plans seeded.")


async def initialize_services():
    """Initialize all services"""
    logger.info("Initializing services...")
    await openai_service.initialize()
    await scraper_service.initialize()
    logger.info("Services initialized.")


def main():
    """Main entry point"""
    # Configure logging
    logger.add(
        settings.LOG_FILE,
        rotation="10 MB",
        retention="30 days",
        level=settings.LOG_LEVEL,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
    )

    logger.info("=" * 50)
    logger.info("DataBot - Starting...")
    logger.info("=" * 50)

    # Check environment variables
    if not settings.TELEGRAM_BOT_TOKEN:
        logger.error("ERROR: TELEGRAM_BOT_TOKEN is not set!")
        logger.error("Please set TELEGRAM_BOT_TOKEN in .env file")
        sys.exit(1)

    if not settings.OPENAI_API_KEY:
        logger.warning("WARNING: OPENAI_API_KEY is not set!")
        logger.warning("AI Assistant will not work without this.")

    # Initialize database
    logger.info("Initializing database...")
    init_db()
    logger.info("Database initialized.")

    # Seed default data
    seed_default_data()

    # Run mode selection
    print("\n" + "=" * 50)
    print("اختر وضع التشغيل:")
    print("=" * 50)
    print("1. تشغيل البوت فقط")
    print("2. تشغيل لوحة التحكم فقط")
    print("3. تشغيل الكل (بوت + لوحة تحكم)")
    print("4. تشغيل البوت فقط (no input)")
    print("=" * 50)

    choice = input("\nاختيارك (1-4): ").strip()

    if choice == '1':
        # Bot only
        logger.info("Running Telegram Bot only...")
        asyncio.run(run_bot())

    elif choice == '2':
        # Dashboard only
        logger.info("Running Dashboard only...")
        run_dashboard()

    elif choice == '3':
        # Both
        logger.info("Running both Bot and Dashboard...")

        # Start bot in separate thread
        bot_thread = threading.Thread(target=lambda: asyncio.run(run_bot()), daemon=True)
        bot_thread.start()

        # Start dashboard
        run_dashboard()

    elif choice == '4':
        # Bot only - no input mode
        logger.info("Running Telegram Bot (headless)...")
        asyncio.run(run_bot())

    else:
        logger.error("خيار غير صالح!")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)