# README - بوت سكرابينج البيانات مع مساعد AI

## المشروع

بوت تيليجرام احترافي للسكرابينج البيانات مع مساعد ذكي يفهم اللغة الطبيعية. يشمل لوحة تحكم أدمن شاملة لإدارة المستخدمين والاشتراكات والإعدادات.

---

## المميزات

### 🤖 مساعد AI
- يفهم اللغة الطبيعية (العربية والإنجليزية)
- يترجم أوامر المستخدم إلى إجراءات
- مثال: "عايز أرجع بيانات من موقع أمازون"

### 📥 قسم السكراب
- سكراب صفحات متعددة
- جدولة السكراب (ساعوي، يومي، أسبوعي)
- اختيار CSS/XPath للتنقية

### 🧹 قسم الكلاننج
- إزالة التكرارات
- تنسيق البيانات (CSV, JSON, Excel)
- فلترة وتصفية

### 💎 نظام الاشتراكات
- 3 باقات (برونز، فضة، ذهب)
- أسعار متعددة (شهري، ربع سنوي، سنوي)
- حدود استخدام مختلفة

### 👨‍💼 لوحة تحكم الأدمن
- إدارة المستخدمين
- إدارة الاشتراكات
- إدارة الباقات
- إدارة النصوص (قابل للتعديل)
- التقارير والإحصائيات
- سجلات النشاط

---

## المتطلبات

- Python 3.10+
- PostgreSQL 14+ (أو SQLite للتجربة)
- Telegram Bot Token
- OpenAI API Key

---

## التثبيت

### 1. استنساخ المشروع
```bash
git clone <repository-url>
cd databot
```

### 2. إنشاء بيئة افتراضية
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# أو
venv\Scripts\activate  # Windows
```

### 3. تثبيت المكتبات
```bash
pip install -r requirements.txt
```

### 4. إعداد المتغيرات البيئية
```bash
cp .env.example .env
```

ثم عدل `.env` وأضف:
```env
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
OPENAI_API_KEY=your_openai_api_key
ADMIN_USERNAME=admin
ADMIN_PASSWORD=your_secure_password
DATABASE_URL=sqlite:///databot.db
```

### 5. الحصول على Telegram Bot Token
1. افتح [@BotFather](https://t.me/BotFather) في تيليجرام
2. ابعت `/newbot`
3. اتبع الخطوات وانسخ الـ Token

### 6. الحصول على OpenAI API Key
1. سجل في [OpenAI](https://platform.openai.com)
2. اذهب لـ API Keys
3. أنشئ مفتاح جديد

---

## التشغيل

### تشغيل البوت
```bash
python -m bot.main
```

### تشغيل لوحة التحكم
```bash
python -m dashboard.app
```

أو تشغيل الكل معاً:
```bash
python run.py
```

---

## الأوامر المتاحة

### أوامر البوت
| الأمر | الوصف |
|-------|-------|
| `/start` | بدء البوت |
| `/help` | المساعدة |
| `/scrape <url>` | سكراب صفحة |
| `/schedule <url> <interval>` | جدولة السكراب |
| `/my_jobs` | عرض وظائفك |
| `/plans` | عرض الباقات |
| `/subscribe` | الاشتراك |
| `/my_subscription` | اشتراكي |
| `/contact` | التواصل |

### أوامر لوحة التحكم
- `/admin` - لوحة التحكم
- `/users` - إدارة المستخدمين
- `/subscriptions` - إدارة الاشتراكات
- `/plans` - إدارة الباقات
- `/texts` - إدارة النصوص
- `/reports` - التقارير
- `/settings` - الإعدادات

---

## هيكل المشروع

```
databot/
├── bot/
│   ├── main.py              # نقطة دخول البوت
│   ├── handlers/            # معالجات الأوامر
│   └── services/            # الخدمات
├── dashboard/
│   ├── app.py               # تطبيق Flask
│   └── templates/            # قوالب HTML
├── database/
│   ├── models.py            # نماذج قاعدة البيانات
│   └── db.py                # إعدادات قاعدة البيانات
├── config/
│   └── settings.py          # الإعدادات
├── requirements.txt
├── .env.example
├── README.md
└── run.py
```

---

## النصوص القابلة للتعديل

يمكنك تعديل النصوص التالية من لوحة التحكم:

| المفتاح | الوصف |
|---------|-------|
| `welcome_message` | رسالة الترحيب |
| `help_text` | نص المساعدة |
| `pricing_title` | عنوان الأسعار |
| `plan_bronze_desc` | وصف البرونز |
| `plan_silver_desc` | وصف الفضة |
| `plan_gold_desc` | وصف الذهب |
| `contact_info` | معلومات التواصل |
| `payment_instructions` | تعليمات الدفع |

---

## الاستضافة

### VPS (Ubuntu 22.04)
```bash
# تثبيت Python
sudo apt update
sudo apt install python3 python3-pip python3-venv

# نسخ المشروع
git clone <repo>
cd databot

# إنشاء بيئة
python3 -m venv venv
source venv/bin/activate

# تثبيت
pip install -r requirements.txt

# إعداد .env
nano .env

# تشغيل كخدمة systemd
sudo nano /etc/systemd/system/databot.service
```

ملف الخدمة:
```ini
[Unit]
Description=DataBot Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/databot
Environment=PATH=/home/ubuntu/databot/venv/bin
ExecStart=/home/ubuntu/databot/venv/bin/python -m bot.main
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable databot
sudo systemctl start databot
```

---

## الأمان

- حماية من SQL Injection
- حماية من XSS
- Rate Limiting
- تشفير كلمات المرور
- سجلات النشاط

---

## الترخيص

MIT License

---

## الدعم

للمساعدة أو الاستفسارات:
- تيليجرام: تواصل مع المطور
- إيميل: support@example.com