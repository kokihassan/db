# -*- coding: utf-8 -*-
"""
Database models for DataBot
"""
from datetime import datetime
from sqlalchemy import Column, Integer, BigInteger, String, Text, Boolean, DateTime, ForeignKey, JSON, Numeric
from sqlalchemy.orm import relationship
from database.db import Base


class User(Base):
    """User model for Telegram users"""
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False, index=True)
    username = Column(String(100), nullable=True)
    first_name = Column(String(100), nullable=True)
    last_name = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    last_seen = Column(DateTime, nullable=True)

    # Relationships
    subscriptions = relationship('Subscription', back_populates='user', lazy='dynamic')
    scrap_jobs = relationship('ScrapJob', back_populates='user', lazy='dynamic')
    requests = relationship('UserRequest', back_populates='user', lazy='dynamic')
    activity_logs = relationship('ActivityLog', back_populates='user', lazy='dynamic')

    @property
    def full_name(self):
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name

    @property
    def has_active_subscription(self):
        return self.subscriptions.filter_by(is_active=True).first() is not None

    def to_dict(self):
        return {
            'id': self.id,
            'telegram_id': self.telegram_id,
            'username': self.username,
            'full_name': self.full_name,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active,
            'is_admin': self.is_admin,
            'has_active_subscription': self.has_active_subscription
        }


class SubscriptionPlan(Base):
    """Subscription plans model"""
    __tablename__ = 'subscription_plans'

    id = Column(Integer, primary_key=True)
    name_ar = Column(String(100), nullable=False)
    name_en = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    price_monthly = Column(Numeric(10, 2), nullable=False)
    price_quarterly = Column(Numeric(10, 2), nullable=True)
    price_yearly = Column(Numeric(10, 2), nullable=True)
    features = Column(JSON, default=dict)
    limits = Column(JSON, default=dict)
    is_active = Column(Boolean, default=True)
    display_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    subscriptions = relationship('Subscription', back_populates='plan', lazy='dynamic')

    def to_dict(self):
        return {
            'id': self.id,
            'name_ar': self.name_ar,
            'name_en': self.name_en,
            'description': self.description,
            'price_monthly': float(self.price_monthly) if self.price_monthly else None,
            'price_quarterly': float(self.price_quarterly) if self.price_quarterly else None,
            'price_yearly': float(self.price_yearly) if self.price_yearly else None,
            'features': self.features,
            'limits': self.limits,
            'is_active': self.is_active,
            'display_order': self.display_order
        }


class Subscription(Base):
    """User subscriptions model"""
    __tablename__ = 'subscriptions'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    plan_id = Column(Integer, ForeignKey('subscription_plans.id'), nullable=False)
    plan_type = Column(String(20), default='monthly')
    price_paid = Column(Numeric(10, 2), nullable=True)
    start_date = Column(DateTime, default=datetime.utcnow)
    end_date = Column(DateTime, nullable=False)
    is_active = Column(Boolean, default=True)
    auto_renew = Column(Boolean, default=False)
    payment_method = Column(String(50), nullable=True)
    payment_reference = Column(String(200), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship('User', back_populates='subscriptions')
    plan = relationship('SubscriptionPlan', back_populates='subscriptions')

    @property
    def is_expired(self):
        return datetime.utcnow() > self.end_date if self.end_date else True

    @property
    def days_remaining(self):
        if self.is_expired:
            return 0
        delta = self.end_date - datetime.utcnow()
        return delta.days

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'plan_id': self.plan_id,
            'plan_name': self.plan.name_ar if self.plan else None,
            'plan_type': self.plan_type,
            'price_paid': float(self.price_paid) if self.price_paid else None,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'is_active': self.is_active,
            'auto_renew': self.auto_renew,
            'days_remaining': self.days_remaining,
            'is_expired': self.is_expired
        }


class ScrapJob(Base):
    """Scraping jobs model"""
    __tablename__ = 'scrap_jobs'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    site_name = Column(String(200), nullable=True)
    site_url = Column(String(500), nullable=False)
    job_type = Column(String(20), default='manual')
    schedule_type = Column(String(20), nullable=True)
    status = Column(String(20), default='pending')
    data_selector = Column(JSON, default=dict)
    cookies = Column(JSON, nullable=True)
    headers = Column(JSON, nullable=True)
    last_run = Column(DateTime, nullable=True)
    next_run = Column(DateTime, nullable=True)
    run_count = Column(Integer, default=0)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship('User', back_populates='scrap_jobs')
    scraped_data = relationship('ScrapedData', back_populates='job', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'site_name': self.site_name,
            'site_url': self.site_url,
            'job_type': self.job_type,
            'schedule_type': self.schedule_type,
            'status': self.status,
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'run_count': self.run_count,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class ScrapedData(Base):
    """Scraped data storage model"""
    __tablename__ = 'scraped_data'

    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey('scrap_jobs.id'), nullable=False)
    raw_data = Column(JSON, nullable=True)
    cleaned_data = Column(JSON, nullable=True)
    record_count = Column(Integer, default=0)
    file_path = Column(String(500), nullable=True)
    scraped_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    job = relationship('ScrapJob', back_populates='scraped_data')

    def to_dict(self):
        return {
            'id': self.id,
            'job_id': self.job_id,
            'record_count': self.record_count,
            'scraped_at': self.scraped_at.isoformat() if self.scraped_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class UserRequest(Base):
    """User requests to AI assistant"""
    __tablename__ = 'user_requests'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    user_message = Column(Text, nullable=False)
    ai_response = Column(Text, nullable=True)
    action_taken = Column(String(50), nullable=True)
    action_params = Column(JSON, nullable=True)
    success = Column(Boolean, default=False)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    user = relationship('User', back_populates='requests')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_message': self.user_message,
            'ai_response': self.ai_response,
            'action_taken': self.action_taken,
            'success': self.success,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Config(Base):
    """Editable texts and configurations"""
    __tablename__ = 'configs'

    id = Column(Integer, primary_key=True)
    config_key = Column(String(100), unique=True, nullable=False, index=True)
    config_value = Column(Text, nullable=True)
    config_type = Column(String(50), default='text')
    category = Column(String(50), index=True)
    description = Column(String(200), nullable=True)
    is_active = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = Column(Integer, ForeignKey('users.id'), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'config_key': self.config_key,
            'config_value': self.config_value,
            'config_type': self.config_type,
            'category': self.category,
            'description': self.description,
            'is_active': self.is_active,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class ActivityLog(Base):
    """Activity logs for auditing"""
    __tablename__ = 'activity_logs'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    action = Column(String(100), nullable=False, index=True)
    entity_type = Column(String(50), nullable=True)
    entity_id = Column(Integer, nullable=True)
    details = Column(JSON, nullable=True)
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationships
    user = relationship('User', back_populates='activity_logs')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action': self.action,
            'entity_type': self.entity_type,
            'entity_id': self.entity_id,
            'details': self.details,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


# Default configs to be seeded
DEFAULT_CONFIGS = [
    # Bot Texts
    {
        'config_key': 'welcome_message',
        'config_value': 'Welcome to the Scraping Bot!\n\nThe bot provides:\n- Smart assistant that understands your requests\n- Scrape data from any website\n- Clean and export data\n\nWrite your request and we will help you!',
        'category': 'bot_text',
        'description': 'Welcome message'
    },
    {
        'config_key': 'help_text',
        'config_value': 'Available commands:\n\n/scrape <url> - Scrape a page\n/scrape_multi - Scrape multiple pages\n/schedule <url> <interval> - Schedule scraping\n/my_jobs - View your jobs\n/clean - Clean data\n/export - Export data\n/plans - View plans\n/subscribe - Subscribe\n/contact - Contact us',
        'category': 'bot_text',
        'description': 'Help text'
    },
    {
        'config_key': 'bot_intro',
        'config_value': 'Smart Scraping Bot - AI Assistant',
        'category': 'bot_text',
        'description': 'Bot introduction'
    },

    # Pricing
    {
        'config_key': 'pricing_title',
        'config_value': 'Subscription Plans',
        'category': 'pricing',
        'description': 'Pricing section title'
    },
    {
        'config_key': 'plan_bronze_desc',
        'config_value': '50 scrapes/day\n1 concurrent job\n7 days storage',
        'category': 'pricing',
        'description': 'Bronze plan description'
    },
    {
        'config_key': 'plan_silver_desc',
        'config_value': '200 scrapes/day\n5 concurrent jobs\n30 days storage\nPriority support',
        'category': 'pricing',
        'description': 'Silver plan description'
    },
    {
        'config_key': 'plan_gold_desc',
        'config_value': 'Unlimited scrapes\nUnlimited jobs\n90 days storage\n24/7 support\nCustom selectors',
        'category': 'pricing',
        'description': 'Gold plan description'
    },

    # Contact
    {
        'config_key': 'contact_info',
        'config_value': 'Contact us:\nWhatsApp: +20XXXXXXXXXX\nEmail: support@example.com',
        'category': 'contact',
        'description': 'Contact information'
    },
    {
        'config_key': 'support_contact',
        'config_value': '+20XXXXXXXXXX',
        'category': 'contact',
        'description': 'Support contact'
    },
    {
        'config_key': 'support_email',
        'config_value': 'support@example.com',
        'category': 'contact',
        'description': 'Support email'
    },
    {
        'config_key': 'payment_instructions',
        'config_value': 'To confirm:\n1. Send the amount to our number\n2. Send a message here with the receipt',
        'category': 'contact',
        'description': 'Payment instructions'
    },

    # Landing
    {
        'config_key': 'landing_title',
        'config_value': 'Smart Scraping Bot',
        'category': 'landing',
        'description': 'Landing title'
    },
    {
        'config_key': 'landing_description',
        'config_value': 'Scrape data from any website easily',
        'category': 'landing',
        'description': 'Landing description'
    },
    {
        'config_key': 'terms',
        'config_value': 'Terms and Conditions:\n1. Using the bot for illegal purposes is prohibited\n2. Scraped data belongs to the user\n3. We reserve the right to suspend any account for misuse',
        'category': 'landing',
        'description': 'Terms and conditions'
    },

    # Subscription
    {
        'config_key': 'subscription_success',
        'config_value': 'Your subscription has been activated successfully! Enjoy the services',
        'category': 'subscription',
        'description': 'Subscription success message'
    },
    {
        'config_key': 'subscription_expired',
        'config_value': 'Your subscription has expired. Please renew to continue.',
        'category': 'subscription',
        'description': 'Subscription expired message'
    },
    {
        'config_key': 'upgrade_prompt',
        'config_value': 'You have {remaining} scrapes remaining today',
        'category': 'subscription',
        'description': 'Upgrade prompt message'
    },
]
