# SPEC.md - بوت تيليجرام للسكرابينج مع AI Assistant ولوحة تحكم كاملة

## 1. Concept & Vision

بوت تيليجرام احترافي للسكرابينج البيانات مع مساعد ذكي يفهم اللغة الطبيعية. المستخدم يقول "عايز أسعار المنتجات من موقع X" والمساعد ي فهم ويقوم بالسكراب تلقائياً بدون أوامر معقدة. لوحة تحكم أدمن شاملة لإدارة المستخدمين والاشتراكات والإعدادات.

**الشعور**: أداة احترافية سهلة الاستخدام - قويه من الداخل، بسيطة من الخارج.

---

## 2. System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    TELEGRAM BOT                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐          │
│  │ AI Assistant│  │  Scraping   │  │  Cleaning   │          │
│  │  (Natural)  │  │   Module    │  │   Module    │          │
│  └─────────────┘  └─────────────┘  └─────────────┘          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   FLASK ADMIN DASHBOARD                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │  Users   │  │ Subscription│ │  Texts   │  │ Settings │     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    PostgreSQL DATABASE                       │
│  Users, Subscriptions, ScrapJobs, Data, Configs, Logs      │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Tech Stack

| المكون | التقنية |
|--------|--------|
| Bot Core | Python 3.10+ + python-telegram-bot v20 |
| AI Assistant | OpenAI API (GPT-4) |
| Web Scraping | Playwright + BeautifulSoup |
| Admin Dashboard | Flask + Bootstrap 5 + AdminLTE |
| Database | PostgreSQL + SQLAlchemy |
| Task Queue | APScheduler |
| Hosting | VPS (Ubuntu 22.04) |

---

## 4. Database Schema

### Users Table
```sql
id: Integer (PK)
telegram_id: BigInteger (unique)
username: String(100)
full_name: String(200)
created_at: DateTime
is_active: Boolean
is_admin: Boolean
```

### Subscriptions Table
```sql
id: Integer (PK)
user_id: Integer (FK)
plan_name: String(50)
plan_type: String(20) -- 'daily', 'monthly', 'yearly'
price: Decimal(10,2)
start_date: DateTime
end_date: DateTime
is_active: Boolean
auto_renew: Boolean
```

### SubscriptionPlans Table
```sql
id: Integer (PK)
name_ar: String(100)
name_en: String(100)
description: Text
price_monthly: Decimal(10,2)
features: JSON
is_active: Boolean
order: Integer
```

### ScrapJobs Table
```sql
id: Integer (PK)
user_id: Integer (FK)
site_url: String(500)
site_name: String(200)
job_type: String(50) -- 'manual', 'scheduled'
schedule: String(50) -- 'hourly', 'daily', 'weekly'
status: String(20) -- 'pending', 'running', 'completed', 'failed'
last_run: DateTime
next_run: DateTime
data_selector: JSON
created_at: DateTime
```

### ScrapedData Table
```sql
id: Integer (PK)
job_id: Integer (FK)
raw_data: JSON
cleaned_data: JSON
scraped_at: DateTime
record_count: Integer
```

### UserRequests Table
```sql
id: Integer (PK)
user_id: Integer (FK)
user_message: Text
ai_response: Text
action_taken: String(50)
created_at: DateTime
```

### Configs Table (Editable Texts)
```sql
id: Integer (PK)
config_key: String(100) (unique)
config_value: Text
category: String(50) -- 'pricing', 'contact', 'bot_text', 'landing'
updated_at: DateTime
updated_by: Integer (FK)
```

### ActivityLogs Table
```sql
id: Integer (PK)
user_id: Integer (FK)
action: String(100)
details: JSON
ip_address: String(50)
created_at: DateTime
```

---

## 5. Telegram Bot Features

### 5.1 AI Assistant (Natural Language)
**Commands:**
- `عايز أرجع بيانات من موقع X`
- `سكراب المنتجات من موقع فلان`
- `نظف البيانات اللي عندي`
- `شوف الأشتركات المتاحة`
- `مساعدني أعمل报告`

**Flow:**
1. User sends natural language request
2. Bot sends to OpenAI API to parse intent
3. AI returns structured command (action + parameters)
4. Bot executes action
5. Bot returns results to user

### 5.2 Scraping Commands
- `/scrape <url>` - سكراب صفحة واحدة
- `/scrape_multi <url1,url2>` - سكراب صفحات متعددة
- `/schedule <url> <interval>` - جدولة السكراب
- `/stop_schedule <job_id>` - إيقاف جدولة
- `/my_jobs` - عرض وظائف السكراب

### 5.3 Data Cleaning Commands
- `/clean <data>` - تنظيف بيانات
- `/dedup` - إزالة التكرارات
- `/export <format>` - تصدير (csv, json, xlsx)
- `/filter <condition>` - فلترة البيانات

### 5.4 Subscription Commands
- `/plans` - عرض الباقات
- `/subscribe <plan>` - اشتراك
- `/my_subscription` - عرض اشتراكي الحالي
- `/renew` - تجديد الاشتراك

### 5.5 General Commands
- `/start` - رسالة الترحيب
- `/help` - المساعدة
- `/contact` - التواصل
- `/stats` - إحصائياتي

---

## 6. Admin Dashboard Features

### 6.1 Dashboard Home
- Total users count
- Active subscriptions
- Total scrapes done
- Recent activity
- Charts: Users growth, Revenue, Scrapes
- Quick actions panel

### 6.2 Users Management
- List all users with pagination
- Search by name/telegram ID
- View user details
- Enable/Disable user
- View user's scrapes and data
- Ban/Unban user
- Add user manually

### 6.3 Subscriptions Management
- View all subscriptions
- Filter by status (active/expired)
- View subscription details
- Create manual subscription
- Extend subscription
- Cancel subscription
- View payment history

### 6.4 Subscription Plans
- CRUD for subscription plans
- Set prices (monthly/quarterly/yearly)
- Define features per plan
- Set limits (scrapes per day, concurrent jobs)
- Activate/deactivate plans
- Reorder plans display

### 6.5 Scraping Jobs Monitor
- List all scrapes (system-wide)
- Filter by status/user
- View job details
- Re-run failed jobs
- Stop running jobs
- View job logs
- Performance metrics

### 6.6 Scraping Sites Management
- Add/Edit scraping configurations
- Define data selectors (CSS/XPath)
- Test selectors
- Manage cookies/headers
- View scraping history per site

### 6.7 Data Management
- View all scraped data
- Search data
- Export data (bulk)
- Delete old data
- Data compression/archival

### 6.8 Text Content Management (قسم النصوص)
**Editable Texts:**
- `/plans` command response
- Welcome message
- Help text
- Contact info
- Pricing section
- Terms & conditions
- Bot buttons text

**Features:**
- WYSIWYG editor
- Preview before save
- Multi-language support
- Version history
- Quick edit for common texts

### 6.9 Contact & Settings
- Contact information (WhatsApp, Email)
- Social media links
- Bot intro text
- Pricing page content
- Landing page content

### 6.10 Reports & Analytics
- User growth report
- Revenue report
- Scraping activity report
- Subscription report
- Export reports to PDF/Excel

### 6.11 Activity Logs
- All user actions
- Admin actions
- System events
- Filter by date/action/user
- Export logs

### 6.12 Settings
- Bot settings (commands, messages)
- API Keys management
- Database backup
- Cache management
- Security settings
- Notification settings

---

## 7. Subscription System

### Plans Structure
```
Bronze Plan:
  - 50 scrapes/day
  - 1 concurrent job
  - 7 days data retention
  - Email support

Silver Plan:
  - 200 scrapes/day
  - 5 concurrent jobs
  - 30 days data retention
  - Priority support
  - API access

Gold Plan:
  - Unlimited scrapes
  - Unlimited jobs
  - 90 days data retention
  - 24/7 support
  - Custom selectors
  - Priority queue
```

### Subscription Flow
1. User calls `/subscribe`
2. Bot shows available plans
3. User selects plan
4. Bot shows payment instructions (manual/admin)
5. Admin confirms payment
6. Subscription activated

---

## 8. AI Assistant Integration

### Intent Detection Prompt
```
You are a scraping assistant. Parse user messages and return:
{
  "action": "scrape|clean|schedule|report|help",
  "target": "url or data",
  "parameters": {},
  "confidence": 0.0-1.0
}

User message: "{message}"
```

### Actions Mapping
- scrape → Run scraper
- clean → Run data cleaner
- schedule → Create scheduled job
- report → Generate report
- help → Show help

---

## 9. File Structure

```
databot/
├── bot/
│   ├── __init__.py
│   ├── main.py              # Bot entry point
│   ├── handlers/
│   │   ├── __init__.py
│   │   ├── ai_assistant.py
│   │   ├── scraping.py
│   │   ├── cleaning.py
│   │   ├── subscription.py
│   │   └── general.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── openai_service.py
│   │   ├── scraper.py
│   │   ├── cleaner.py
│   │   └── subscription_service.py
│   └── utils/
│       ├── __init__.py
│       └── helpers.py
├── dashboard/
│   ├── __init__.py
│   ├── app.py               # Flask app
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── admin.py
│   │   ├── users.py
│   │   ├── subscriptions.py
│   │   ├── scraping.py
│   │   ├── texts.py
│   │   └── settings.py
│   └── templates/
│       └── admin/
├── database/
│   ├── __init__.py
│   ├── models.py
│   └── db.py
├── config/
│   ├── __init__.py
│   └── settings.py
├── requirements.txt
├── .env.example
├── README.md
└── run.py
```

---

## 10. Configuration Keys (Editable via Dashboard)

| Key | Description |
|-----|-------------|
| `welcome_message` | رسالة الترحيب |
| `help_text` | نص المساعدة |
| `pricing_text` | نص الأسعار |
| `contact_info` | معلومات التواصل |
| `bot_intro` | مقدمة البوت |
| `terms` | الشروط والأحكام |
| `plan_bronze_desc` | وصف باقة البرونز |
| `plan_silver_desc` | وصف باقة الفضة |
| `plan_gold_desc` | وصف باقة الذهب |
| `payment_instructions` | تعليمات الدفع |
| `support_contact` | جهة الدعم |

---

## 11. Security Features

- Rate limiting (100 requests/minute per user)
- User authentication via Telegram ID
- Admin authentication via password
- SQL injection prevention
- XSS prevention
- CSRF protection
- Input validation
- Logging all actions

---

## 12. Deployment

### Requirements
- Ubuntu 22.04 VPS
- Python 3.10+
- PostgreSQL 14+
- Redis (optional for caching)

### Steps
1. Clone repository
2. Install dependencies
3. Configure environment variables
4. Setup PostgreSQL database
5. Run migrations
6. Start bot service
7. Start dashboard service
8. Setup nginx (optional)
9. Setup systemd service

---

## 13. Future Enhancements

- [ ] Multi-language support
- [ ] Payment gateway integration
- [ ] Mobile app
- [ ] Chrome extension
- [ ] API for external developers
- [ ] Team collaboration
- [ ] Custom scraper builder