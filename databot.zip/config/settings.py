"""
Configuration settings for DataBot
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Base directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Environment
ENV = os.getenv('ENV', 'development')
DEBUG = ENV == 'development'

# Telegram Bot
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
BOT_USERNAME = os.getenv('BOT_USERNAME', 'DataBot')

# OpenAI
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4-turbo')

# Database
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///databot.db')

# Admin Dashboard
SECRET_KEY = os.getenv('SECRET_KEY', 'change-me-in-production')
ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')
ADMIN_TELEGRAM_ID = os.getenv('ADMIN_TELEGRAM_ID', '')

# Scraping Settings
SCRAPE_TIMEOUT = int(os.getenv('SCRAPE_TIMEOUT', '60'))
MAX_CONCURRENT_JOBS = int(os.getenv('MAX_CONCURRENT_JOBS', '5'))

# Rate Limiting
RATE_LIMIT_REQUESTS = int(os.getenv('RATE_LIMIT_REQUESTS', '100'))
RATE_LIMIT_WINDOW = int(os.getenv('RATE_LIMIT_WINDOW', '60'))

# Data Retention
DATA_RETENTION_DAYS = int(os.getenv('DATA_RETENTION_DAYS', '30'))

# Logging
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = BASE_DIR / 'logs' / 'databot.log'

# Create logs directory
(BASE_DIR / 'logs').mkdir(exist_ok=True)