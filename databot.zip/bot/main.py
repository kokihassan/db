# -*- coding: utf-8 -*-
"""
Telegram Bot Main Entry Point
"""
import logging
from pathlib import Path
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
from loguru import logger

from config import settings
from database import init_db, db_session, Config
from bot.handlers import AIAssistantHandler, ScrapingHandler, SubscriptionHandler, GeneralHandler
from bot.services import openai_service, scraper_service

# Configure logging
logger.add(
    settings.LOG_FILE,
    rotation="10 MB",
    retention="30 days",
    level=settings.LOG_LEVEL
)

# Bot token validation
if not settings.TELEGRAM_BOT_TOKEN:
    logger.error("TELEGRAM_BOT_TOKEN is not set!")
    raise ValueError("TELEGRAM_BOT_TOKEN must be set in environment")


class DataBot:
    """Main Telegram Bot class"""

    def __init__(self):
        self.app = None

    async def initialize(self):
        """Initialize bot and services"""
        logger.info("Initializing DataBot...")

        # Initialize database
        init_db()
        logger.info("Database initialized")

        # Initialize services
        await openai_service.initialize()
        await scraper_service.initialize()
        logger.info("Services initialized")

        # Create application
        self.app = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()

        # Register handlers
        self._register_handlers()

        logger.info("Bot handlers registered")

    def _register_handlers(self):
        """Register all command handlers"""

        # General commands
        self.app.add_handler(CommandHandler("start", GeneralHandler.start_command))
        self.app.add_handler(CommandHandler("help", GeneralHandler.help_command))
        self.app.add_handler(CommandHandler("contact", GeneralHandler.contact_command))
        self.app.add_handler(CommandHandler("stats", GeneralHandler.stats_command))
        self.app.add_handler(CommandHandler("clean", GeneralHandler.clean_command))
        self.app.add_handler(CommandHandler("export", GeneralHandler.export_command))
        self.app.add_handler(CommandHandler("cancel", GeneralHandler.cancel_command))

        # Scraping commands
        self.app.add_handler(CommandHandler("scrape", ScrapingHandler.scrape_command))
        self.app.add_handler(CommandHandler("scrape_multi", ScrapingHandler.scrape_multi_command))
        self.app.add_handler(CommandHandler("schedule", ScrapingHandler.schedule_command))
        self.app.add_handler(CommandHandler("my_jobs", ScrapingHandler.my_jobs_command))

        # Subscription commands
        self.app.add_handler(CommandHandler("plans", SubscriptionHandler.plans_command))
        self.app.add_handler(CommandHandler("subscribe", SubscriptionHandler.subscribe_command))
        self.app.add_handler(CommandHandler("my_subscription", SubscriptionHandler.my_subscription_command))
        self.app.add_handler(CommandHandler("renew", SubscriptionHandler.renew_command))

        # Callback query handler
        self.app.add_handler(CallbackQueryHandler(self._handle_callback))

        # Message handler for AI assistant (must be last)
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, AIAssistantHandler.handle_message))

    async def _handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries from inline buttons"""
        query = update.callback_query
        await query.answer()

        data = query.data

        # Handle subscription callbacks
        if data.startswith("sub_"):
            parts = data.split("_")
            plan_id = int(parts[1])
            plan_type = parts[2] if len(parts) > 2 else "monthly"

            # Get payment instructions
            payment_text = db_session.query(Config).filter_by(config_key='payment_instructions').first()
            instructions = payment_text.config_value if payment_text else "Contact us to subscribe"

            await query.edit_message_text(
                f"Subscription Request\n\n"
                f"Plan: {plan_id}\n"
                f"Type: {plan_type}\n\n"
                f"Payment Method:\n{instructions}\n\n"
                "Send payment receipt here"
            )

        elif data == "contact_admin":
            contact = db_session.query(Config).filter(Config.config_key == 'contact_info').first()
            contact_text = contact.config_value if contact else "Contact: support@example.com"
            await query.edit_message_text(contact_text)

        # Handle menu buttons
        elif data == "cmd_scrape":
            await query.edit_message_text(
                "Scraping:\n\n"
                "Send the URL you want to scrape, example:\n"
                "https://www.amazon.com\n\n"
                "Or use command /scrape <url>"
            )
        elif data == "cmd_subscribe":
            await SubscriptionHandler.plans_command(update, context)
        elif data == "cmd_stats":
            await GeneralHandler.stats_command(update, context)
        elif data == "cmd_contact":
            await GeneralHandler.contact_command(update, context)
        elif data == "cmd_help":
            await GeneralHandler.help_command(update, context)

    async def run(self):
        """Run the bot"""
        logger.info("Starting DataBot...")

        await self.initialize()

        logger.info("Bot is running!")
        await self.app.run_polling(drop_pending_updates=True)

    async def shutdown(self):
        """Shutdown bot gracefully"""
        logger.info("Shutting down DataBot...")
        await scraper_service.close()
        if self.app:
            await self.app.stop()


# Global bot instance
bot = DataBot()


def main():
    """Main entry point"""
    import asyncio

    async def run_bot():
        try:
            await bot.run()
        except KeyboardInterrupt:
            pass
        finally:
            await bot.shutdown()

    asyncio.run(run_bot())


if __name__ == "__main__":
    main()
