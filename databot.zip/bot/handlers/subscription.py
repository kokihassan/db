"""
Subscription Handlers
"""
from loguru import logger
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from bot.services import subscription_service
from database import db_session, User, Config


class SubscriptionHandler:
    """Handler for subscription commands"""

    @staticmethod
    async def plans_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /plans command"""
        plans = subscription_service.get_available_plans()

        if not plans:
            await update.message.reply_text("❌ لا توجد باقات متاحة حالياً.")
            return

        # Get editable text for pricing
        pricing_title = db_session.query(Config).filter(Config.config_key == 'pricing_title').first()
        title = pricing_title.config_value if pricing_title else "💰 باقات الاشتراك"

        text = f"{title}\n\n"

        for plan in plans:
            features = plan.features or {}
            features_text = "\n".join([f"  ✓ {f}" for f in features.get('items', [])])

            text += f"📦 {plan.name_ar}\n"
            text += f"💵 {plan.price_monthly} $/شهر\n"
            if features_text:
                text += f"{features_text}\n"
            text += "\n"

        keyboard = []
        for plan in plans:
            keyboard.append([
                InlineKeyboardButton(
                    f"اشترك {plan.name_ar}",
                    callback_data=f"sub_{plan.id}_monthly"
                )
            ])

        keyboard.append([
            InlineKeyboardButton("📞 تواصل معنا", callback_data="contact_admin")
        ])

        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(text, reply_markup=reply_markup)

    @staticmethod
    async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /subscribe command"""
        plans = subscription_service.get_available_plans()

        if not plans:
            await update.message.reply_text("❌ لا توجد باقات متاحة حالياً.")
            return

        text = "💎 اختر الباقة:\n\n"

        for i, plan in enumerate(plans, 1):
            text += f"{i}. {plan.name_ar}\n"
            text += f"   💵 {plan.price_monthly}/شهر\n"
            text += f"   📝 {plan.description or 'لا يوجد وصف'}\n\n"

        text += "\nللتأكيد أو الاستفسار تواصل معنا: /contact"

        await update.message.reply_text(text)

    @staticmethod
    async def my_subscription_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /my_subscription command"""
        user_id = update.effective_user.id
        user = db_session.query(User).filter(User.telegram_id == user_id).first()

        if not user:
            return

        subscription = subscription_service.get_user_subscription(user.id)

        if not subscription:
            await update.message.reply_text(
                "❌ ليس لديك اشتراك نشط.\n\n"
                "للاشتراك: /subscribe\n"
                "للتواصل: /contact"
            )
            return

        days_remaining = subscription.days_remaining

        text = f"💎 اشتراكك الحالي:\n\n"
        text += f"📦 الباقة: {subscription.plan.name_ar if subscription.plan else 'غير محدد'}\n"
        text += f"📅 تاريخ البدء: {subscription.start_date.strftime('%Y-%m-%d')}\n"
        text += f"📅 تاريخ الانتهاء: {subscription.end_date.strftime('%Y-%m-%d')}\n"
        text += f"⏳ أيام متبقية: {days_remaining}\n"
        text += f"🔄 تجديد تلقائي: {'نعم' if subscription.auto_renew else 'لا'}\n"

        if days_remaining <= 3:
            text += "\n⚠️ اشتراكك على وشك الانتهاء!"

        await update.message.reply_text(text)

    @staticmethod
    async def renew_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /renew command"""
        user_id = update.effective_user.id
        user = db_session.query(User).filter(User.telegram_id == user_id).first()

        if not user:
            return

        subscription = subscription_service.get_user_subscription(user.id)

        if not subscription:
            await update.message.reply_text("❌ ليس لديك اشتراك للتجديد.")
            return

        text = f"🔄 تجديد الاشتراك\n\n"
        text += f"اشتراكك الحالي: {subscription.plan.name_ar}\n"
        text += f"ينتهي في: {subscription.end_date.strftime('%Y-%m-%d')}\n\n"

        # Get payment instructions
        payment_text = db_session.query(Config).filter(Config.config_key == 'payment_instructions').first()
        instructions = payment_text.config_value if payment_text else "تواصل معنا للتجديد"

        text += f"📋 طريقة التجديد:\n{instructions}\n\n"
        text += "للمساعدة: /contact"

        await update.message.reply_text(text)