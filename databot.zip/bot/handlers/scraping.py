"""
Scraping Handlers
"""
from loguru import logger
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from bot.services import scraper_service, subscription_service
from database import db_session, User, ScrapJob, ScrapedData, Config


class ScrapingHandler:
    """Handler for scraping commands"""

    @staticmethod
    async def scrape_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape command"""
        user_id = update.effective_user.id

        # Check subscription
        can_scrape = subscription_service.check_user_can_scrape(user_id)
        if not can_scrape['can_scrape']:
            if not can_scrape['has_subscription']:
                await update.message.reply_text(
                    "❌ ليس لديك اشتراك نشط.\n"
                    "استخدم /subscribe للاشتراك."
                )
            else:
                await update.message.reply_text(
                    f"⚠️ وصلت للحد الأقصى.\n\n"
                    f"📊 استخدامك اليوم: {can_scrape['scrapes_today']}/{can_scrape['scrapes_limit']}\n"
                    f"🔄 الوظائف النشطة: {can_scrape['active_jobs']}/{can_scrape['jobs_limit']}\n\n"
                    "للترقية: /subscribe"
                )
            return

        if not context.args:
            await update.message.reply_text(
                "📥 أمر السكراب:\n\n"
                "/scrape <رابط الموقع>\n\n"
                "مثال: /scrape https://www.amazon.com"
            )
            return

        url = context.args[0]
        await update.message.reply_text(f"🔄 جاري سكراب {url}...")

        result = await scraper_service.scrape_url(url)

        if result['success']:
            # Create scrap job record
            user = db_session.query(User).filter(User.telegram_id == user_id).first()
            if user:
                job = ScrapJob(
                    user_id=user.id,
                    site_name=urlparse(url).netloc if hasattr(__import__('urllib.parse'), 'urlparse') else url,
                    site_url=url,
                    job_type='manual',
                    status='completed',
                    last_run=datetime.utcnow(),
                    run_count=1
                )
                db_session.add(job)

                # Store scraped data
                data = ScrapedData(
                    job=job,
                    raw_data=result['data'],
                    record_count=1
                )
                db_session.add(data)
                db_session.commit()

            data = result['data']
            preview = f"✅ تم السكراب بنجاح!\n\n"
            preview += f"📌 العنوان: {data.get('title', 'غير متاح')}\n"

            if data.get('text_content'):
                preview += f"\n📝 المحتوى:\n{data['text_content'][:800]}..."

            await update.message.reply_text(preview)
        else:
            await update.message.reply_text(f"❌ فشل السكراب: {result.get('error')}")

    @staticmethod
    async def scrape_multi_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape_multi command"""
        await update.message.reply_text(
            "📥 سكراب صفحات متعددة:\n\n"
            "أرسل الروابط مفصولة بفواصل:\n"
            "https://site1.com, https://site2.com, https://site3.com"
        )

    @staticmethod
    async def schedule_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /schedule command"""
        user_id = update.effective_user.id

        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "⏰ جدولة السكراب:\n\n"
                "/schedule <رابط> <تكرار>\n\n"
                "التكرار: hourly, daily, weekly\n\n"
                "مثال: /schedule https://example.com daily"
            )
            return

        url = context.args[0]
        schedule = context.args[1].lower()

        if schedule not in ['hourly', 'daily', 'weekly']:
            await update.message.reply_text("❌ تكرار غير صحيح. استخدم: hourly, daily, أو weekly")
            return

        user = db_session.query(User).filter(User.telegram_id == user_id).first()
        if not user:
            return

        job = ScrapJob(
            user_id=user.id,
            site_name=url,
            site_url=url,
            job_type='scheduled',
            schedule_type=schedule,
            status='pending'
        )
        db_session.add(job)
        db_session.commit()

        await update.message.reply_text(
            f"✅ تم جدولة السكراب!\n\n"
            f"🔗 الرابط: {url}\n"
            f"⏱️ التكرار: {schedule}\n\n"
            "للإلغاء استخدم /stop_schedule"
        )

    @staticmethod
    async def my_jobs_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /my_jobs command"""
        user_id = update.effective_user.id
        user = db_session.query(User).filter(User.telegram_id == user_id).first()

        if not user:
            return

        jobs = db_session.query(ScrapJob).filter(
            ScrapJob.user_id == user.id
        ).order_by(ScrapJob.created_at.desc()).limit(10).all()

        if not jobs:
            await update.message.reply_text("📭 ليس لديك وظائف سكراب.")
            return

        text = "📋 وظائف السكراب:\n\n"
        for job in jobs:
            status_emoji = {
                'pending': '⏳',
                'running': '🔄',
                'completed': '✅',
                'failed': '❌',
                'stopped': '🛑'
            }.get(job.status, '❓')

            text += f"{status_emoji} {job.site_name or job.site_url[:30]}...\n"
            text += f"   النوع: {job.job_type} | التكرار: {job.schedule_type or 'يدوي'}\n"
            text += f"   الحالة: {job.status} | مرات التشغيل: {job.run_count}\n\n"

        await update.message.reply_text(text)


from datetime import datetime