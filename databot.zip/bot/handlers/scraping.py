# -*- coding: utf-8 -*-
"""
Scraping Handlers
"""
from datetime import datetime
from urllib.parse import urlparse
from loguru import logger
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from bot.services import scraper_service, subscription_service
from database import db_session, User, ScrapJob, ScrapedData, Config


class ScrapingHandler:
    """Handler for scraping commands"""

    @staticmethod
    async def scrape_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape command"""
        user_id = update.effective_user.id

        # Check subscription
        can_scrape = subscription_service.check_user_can_scrape(user_id)
        if not can_scrape['can_scrape']:
            if not can_scrape['has_subscription']:
                await update.message.reply_text(
                    "You don't have an active subscription.\n"
                    "Use /subscribe to subscribe."
                )
            else:
                await update.message.reply_text(
                    f"You've reached the limit.\n\n"
                    f"Today's usage: {can_scrape['scrapes_today']}/{can_scrape['scrapes_limit']}\n"
                    f"Active jobs: {can_scrape['active_jobs']}/{can_scrape['jobs_limit']}\n\n"
                    "To upgrade: /subscribe"
                )
            return

        if not context.args:
            await update.message.reply_text(
                "Scrape command:\n\n"
                "/scrape <url>\n\n"
                "Example: /scrape https://www.amazon.com"
            )
            return

        url = context.args[0]
        await update.message.reply_text(f"Scraping {url}...")

        result = await scraper_service.scrape_url(url)

        if result['success']:
            # Create scrap job record
            user = db_session.query(User).filter(User.telegram_id == user_id).first()
            if user:
                parsed = urlparse(url)
                site_name = parsed.netloc if parsed.netloc else url

                job = ScrapJob(
                    user_id=user.id,
                    site_name=site_name,
                    site_url=url,
                    job_type='manual',
                    status='completed',
                    last_run=datetime.utcnow(),
                    run_count=1
                )
                db_session.add(job)

                # Store scraped data
                data = ScrapedData(
                    job=job,
                    raw_data=result['data'],
                    record_count=1
                )
                db_session.add(data)
                db_session.commit()

            data = result['data']
            preview = f"Scraping successful!\n\n"
            preview += f"Title: {data.get('title', 'N/A')}\n"

            if data.get('text_content'):
                preview += f"\nContent:\n{data['text_content'][:800]}..."

            await update.message.reply_text(preview)
        else:
            await update.message.reply_text(f"Scraping failed: {result.get('error')}")

    @staticmethod
    async def scrape_multi_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /scrape_multi command"""
        await update.message.reply_text(
            "Scrape multiple pages:\n\n"
            "Send URLs separated by commas:\n"
            "https://site1.com, https://site2.com, https://site3.com"
        )

    @staticmethod
    async def schedule_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /schedule command"""
        user_id = update.effective_user.id

        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "Schedule scraping:\n\n"
                "/schedule <url> <interval>\n\n"
                "Interval: hourly, daily, weekly\n\n"
                "Example: /schedule https://example.com daily"
            )
            return

        url = context.args[0]
        schedule = context.args[1].lower()

        if schedule not in ['hourly', 'daily', 'weekly']:
            await update.message.reply_text("Invalid interval. Use: hourly, daily, or weekly")
            return

        user = db_session.query(User).filter(User.telegram_id == user_id).first()
        if not user:
            return

        job = ScrapJob(
            user_id=user.id,
            site_name=url,
            site_url=url,
            job_type='scheduled',
            schedule_type=schedule,
            status='pending'
        )
        db_session.add(job)
        db_session.commit()

        await update.message.reply_text(
            f"Scraping scheduled!\n\n"
            f"URL: {url}\n"
            f"Interval: {schedule}\n\n"
            "Use /stop_schedule to cancel"
        )

    @staticmethod
    async def my_jobs_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /my_jobs command"""
        user_id = update.effective_user.id
        user = db_session.query(User).filter(User.telegram_id == user_id).first()

        if not user:
            return

        jobs = db_session.query(ScrapJob).filter(
            ScrapJob.user_id == user.id
        ).order_by(ScrapJob.created_at.desc()).limit(10).all()

        if not jobs:
            await update.message.reply_text("You don't have any scraping jobs.")
            return

        text = "Scraping Jobs:\n\n"
        for job in jobs:
            status_emoji = {
                'pending': 'Pending',
                'running': 'Running',
                'completed': 'Done',
                'failed': 'Failed',
                'stopped': 'Stopped'
            }.get(job.status, 'Unknown')

            text += f"{status_emoji}: {job.site_name or job.site_url[:30]}...\n"
            text += f"   Type: {job.job_type} | Interval: {job.schedule_type or 'manual'}\n"
            text += f"   Status: {job.status} | Runs: {job.run_count}\n\n"

        await update.message.reply_text(text)
