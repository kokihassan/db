"""
AI Assistant Handler
"""
import json
from loguru import logger
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from bot.services import openai_service, scraper_service, cleaner_service, subscription_service
from database import db_session, User, UserRequest


class AIAssistantHandler:
    """Handler for AI-powered natural language commands"""

    @staticmethod
    async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle user's natural language message"""
        user_id = update.effective_user.id
        message = update.message.text.strip()

        # Get user
        user = db_session.query(User).filter(User.telegram_id == user_id).first()
        if not user:
            await update.message.reply_text("لم يتم العثور على حسابك. يرجى استخدام /start أولاً.")
            return

        # Send "typing" indicator
        await update.message.chat.send_action('typing')

        # Parse intent using AI
        intent = await openai_service.parse_user_intent(message)

        logger.info(f"User {user_id} intent: {intent}")

        # Log the request
        user_request = UserRequest(
            user_id=user.id,
            user_message=message,
            ai_response=json.dumps(intent),
            action_taken=intent.get('action'),
            action_params=intent.get('parameters'),
            success=True
        )
        db_session.add(user_request)
        db_session.commit()

        # Handle based on action
        action = intent.get('action', 'help')
        target = intent.get('target', '')
        parameters = intent.get('parameters', {})

        if action == 'scrape':
            await AIAssistantHandler._handle_scrape(update, target, parameters)
        elif action == 'clean':
            await AIAssistantHandler._handle_clean(update, parameters)
        elif action == 'schedule':
            await AIAssistantHandler._handle_schedule(update, target, parameters)
        elif action == 'report':
            await AIAssistantHandler._handle_report(update, context)
        elif action == 'subscribe':
            await AIAssistantHandler._handle_subscribe(update, context)
        elif action == 'contact':
            await AIAssistantHandler._handle_contact(update)
        elif action == 'help':
            await AIAssistantHandler._handle_help(update)
        elif action == 'error':
            await update.message.reply_text(
                "عذراً، لم أتمكن من فهم طلبك. هل يمكنك إعادة صياغة الطلب؟\n\n"
                "مثال: 'عايز أسكراب المنتجات من موقع أمازون'"
            )
        else:
            response = await openai_service.generate_response(message)
            await update.message.reply_text(response)

    @staticmethod
    async def _handle_scrape(update: Update, url: str, parameters: dict):
        """Handle scraping request"""
        if not url:
            await update.message.reply_text(
                "❌ لم أجد رابط في طلبك.\n\n"
                "يرجى تحديد الموقع الذي تريد سكرابه.\n"
                "مثال: 'سكراب المنتجات من https://www.amazon.com'"
            )
            return

        await update.message.reply_text(f"🔄 جاري سكراب {url}...")

        result = await scraper_service.scrape_url(url, parameters.get('selectors'))

        if result['success']:
            data = result['data']
            if isinstance(data, dict):
                preview = f"✅ تم سكراب البيانات بنجاح!\n\n"
                preview += f"📌 العنوان: {data.get('title', 'غير متاح')}\n"
                preview += f"🔗 عدد الروابط: {len(data.get('links', []))}\n"
                preview += f"🖼️ عدد الصور: {len(data.get('images', []))}\n"

                if data.get('text_content'):
                    preview += f"\n📝 معاينة النص:\n{data['text_content'][:500]}..."

                await update.message.reply_text(preview)
            else:
                await update.message.reply_text("✅ تم سكراب البيانات بنجاح!")
        else:
            await update.message.reply_text(f"❌ فشل السكراب: {result.get('error', 'خطأ غير معروف')}")

    @staticmethod
    async def _handle_clean(update: Update, parameters: dict):
        """Handle data cleaning request"""
        await update.message.reply_text(
            "🧹 لأ تنظيف البيانات:\n\n"
            "1. أرسل لي البيانات تريد تنظيفها (CSV أو JSON)\n"
            "2. أو استخدم الأمر /clean followed by your data"
        )

    @staticmethod
    async def _handle_schedule(update: Update, url: str, parameters: dict):
        """Handle scheduling request"""
        if not url:
            await update.message.reply_text(
                "❌ لم أجد رابط.\n\n"
                "مثال: 'جدول سكراب من https://example.com كل ساعة'"
            )
            return

        interval = parameters.get('interval', 'daily')
        await update.message.reply_text(
            f"⏰ تم جدولة السكراب لـ {url}\n"
            f"⏱️ التكرار: {interval}\n\n"
            f"للتحكم في الجدولة استخدم /my_jobs"
        )

    @staticmethod
    async def _handle_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle report request"""
        user_id = update.effective_user.id
        user = db_session.query(User).filter(User.telegram_id == user_id).first()

        if not user:
            return

        # Get user's stats
        from database import ScrapJob, ScrapedData
        from sqlalchemy import func

        total_jobs = db_session.query(func.count(ScrapJob.id)).filter(ScrapJob.user_id == user.id).scalar()
        completed_jobs = db_session.query(func.count(ScrapJob.id)).filter(
            ScrapJob.user_id == user.id,
            ScrapJob.status == 'completed'
        ).scalar()

        report = f"📊 تقريرك:\n\n"
        report += f"📁 إجمالي الوظائف: {total_jobs}\n"
        report += f"✅ مكتملة: {completed_jobs}\n"
        report += f"⏳ قيد التنفيذ: {total_jobs - completed_jobs}\n"

        # Subscription info
        sub = subscription_service.get_user_subscription(user.id)
        if sub:
            report += f"\n💎 اشتراكك: {sub.plan.name_ar}\n"
            report += f"📅 ينتهي في: {sub.end_date.strftime('%Y-%m-%d')}\n"
        else:
            report += f"\n⚠️ ليس لديك اشتراك نشط"

        await update.message.reply_text(report)

    @staticmethod
    async def _handle_subscribe(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle subscription request"""
        plans = subscription_service.get_available_plans()

        if not plans:
            await update.message.reply_text("❌ لا توجد باقات متاحة حالياً.")
            return

        keyboard = []
        for plan in plans:
            keyboard.append([
                InlineKeyboardButton(
                    f"{plan.name_ar} - {plan.price_monthly} $/شهر",
                    callback_data=f"subscribe_{plan.id}"
                )
            ])

        keyboard.append([InlineKeyboardButton("📞 تواصل معنا", callback_data="contact_admin")])

        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            "💰 الباقات المتاحة:\n\n"
            "اختر الباقة المناسبة لك:",
            reply_markup=reply_markup
        )

    @staticmethod
    async def _handle_contact(update: Update):
        """Handle contact info request"""
        from database import Config

        contact = db_session.query(Config).filter(Config.config_key == 'contact_info').first()
        message = contact.config_value if contact else "📱 للتواصل: support@example.com"

        await update.message.reply_text(message)

    @staticmethod
    async def _handle_help(update: Update):
        """Handle help request"""
        help_text = """
🤖 مساعد الذكاء الاصطناعي

اكتب طلبك بشكل طبيعي وسأساعدك!

📥 أمثلة على السكراب:
• "عايز أرجع بيانات من موقع أمازون"
• "سكراب أسعار المنتجات من الموقع الفلاني"
• "استخرج العناوين من الرابط ده"

🧹 أمثلة على التنظيف:
• "نظف البيانات دي"
• "أزل التكرارات"

📊 أمثلة على التقارير:
• "شوف إحصائياتي"
• "اعرض تقرير الأشتركات"

💎 للاستفسار عن الأشتركات:
• "شوف الباقات"
• "عايز أشترك"
"""
        await update.message.reply_text(help_text)