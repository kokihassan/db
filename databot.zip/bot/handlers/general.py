"""
General Handlers
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import db_session, User, Config


class GeneralHandler:
    """Handler for general bot commands"""

    @staticmethod
    async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user

        # Create or update user
        db_user = db_session.query(User).filter(User.telegram_id == user.id).first()

        if not db_user:
            db_user = User(
                telegram_id=user.id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                is_active=True
            )
            db_session.add(db_user)
            db_session.commit()

        # Get welcome message
        welcome_config = db_session.query(Config).filter(Config.config_key == 'welcome_message').first()
        welcome_text = welcome_config.config_value if welcome_config else (
            "أهلاً بك في بوت السكرابينج!\n\n"
            "يوفر لك البوت:\n"
            "• مساعد ذكي يفهم طلباتك\n"
            "• سكراب البيانات من أي موقع\n"
            "• تنظيف وتصدير البيانات\n\n"
            "اكتب طلبك وسأساعدك!"
        )

        keyboard = [
            [
                InlineKeyboardButton("📥 سكراب", callback_data="cmd_scrape"),
                InlineKeyboardButton("💎 الاشتراكات", callback_data="cmd_subscribe")
            ],
            [
                InlineKeyboardButton("📊 إحصائياتي", callback_data="cmd_stats"),
                InlineKeyboardButton("📞 تواصل", callback_data="cmd_contact")
            ],
            [
                InlineKeyboardButton("🤖 مساعدة", callback_data="cmd_help")
            ]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(welcome_text, reply_markup=reply_markup)

    @staticmethod
    async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        # Get help text from config
        help_config = db_session.query(Config).filter(Config.config_key == 'help_text').first()
        help_text = help_config.config_value if help_config else (
            "📖 المساعدة\n\n"
            "الأوامر المتاحة:\n\n"
            "/scrape <url> - سكراب صفحة\n"
            "/scrape_multi - سكراب صفحات متعددة\n"
            "/schedule <url> <interval> - جدولة السكراب\n"
            "/my_jobs - عرض وظائفك\n"
            "/clean - تنظيف البيانات\n"
            "/export - تصدير البيانات\n"
            "/plans - عرض الباقات\n"
            "/subscribe - الاشتراك\n"
            "/contact - التواصل معنا\n"
            "/stats - إحصائياتي\n"
            "/help - المساعدة"
        )

        await update.message.reply_text(help_text)

    @staticmethod
    async def contact_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /contact command"""
        # Get contact info from config
        contact_config = db_session.query(Config).filter(Config.config_key == 'contact_info').first()
        contact_text = contact_config.config_value if contact_config else "📱 للتواصل: support@example.com"

        keyboard = [
            [InlineKeyboardButton("💬 محادثة", callback_data="contact_admin")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(contact_text, reply_markup=reply_markup)

    @staticmethod
    async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command"""
        user_id = update.effective_user.id
        user = db_session.query(User).filter(User.telegram_id == user_id).first()

        if not user:
            return

        from database import ScrapJob
        from sqlalchemy import func

        total_jobs = db_session.query(func.count(ScrapJob.id)).filter(
            ScrapJob.user_id == user.id
        ).scalar() or 0

        completed_jobs = db_session.query(func.count(ScrapJob.id)).filter(
            ScrapJob.user_id == user.id,
            ScrapJob.status == 'completed'
        ).scalar() or 0

        active_jobs = db_session.query(func.count(ScrapJob.id)).filter(
            ScrapJob.user_id == user.id,
            ScrapJob.status.in_(['pending', 'running'])
        ).scalar() or 0

        from bot.services import subscription_service
        subscription = subscription_service.get_user_subscription(user.id)

        text = f"📊 إحصائياتك:\n\n"
        text += f"📁 إجمالي الوظائف: {total_jobs}\n"
        text += f"✅ مكتملة: {completed_jobs}\n"
        text += f"🔄 نشطة: {active_jobs}\n"

        if subscription:
            text += f"\n💎 اشتراكك: {subscription.plan.name_ar}\n"
            text += f"📅 ينتهي في: {subscription.end_date.strftime('%Y-%m-%d')}\n"
        else:
            text += f"\n⚠️ ليس لديك اشتراك نشط\n"

        await update.message.reply_text(text)

    @staticmethod
    async def clean_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /clean command"""
        await update.message.reply_text(
            "🧹 تنظيف البيانات\n\n"
            "أرسل البيانات تريد تنظيفها (JSON أو CSV)\n"
            "وسأقوم بـ:\n"
            "• إزالة التكرارات\n"
            "• تنسيق النصوص\n"
            "• إزالة القيم الفارغة"
        )

    @staticmethod
    async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /export command"""
        await update.message.reply_text(
            "📤 تصدير البيانات\n\n"
            "الصيغ المدعومة:\n"
            "• JSON - /export json\n"
            "• CSV - /export csv\n"
            "• TXT - /export txt\n\n"
            "أو أرسل رقم الوظيفة للتصدير"
        )

    @staticmethod
    async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /cancel command"""
        await update.message.reply_text(
            "❌ تم الإلغاء\n\n"
            "إذا احتجت مساعدة: /help"
        )