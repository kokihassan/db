"""
Subscription Service
"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from decimal import Decimal
from loguru import logger

from database import db_session, User, Subscription, SubscriptionPlan


class SubscriptionService:
    """Service for managing subscriptions"""

    @staticmethod
    def get_user_subscription(user_id: int) -> Optional[Subscription]:
        """Get user's active subscription"""
        return db_session.query(Subscription).filter(
            Subscription.user_id == user_id,
            Subscription.is_active == True,
            Subscription.end_date > datetime.utcnow()
        ).first()

    @staticmethod
    def get_user_limits(user_id: int) -> Dict[str, Any]:
        """Get user's usage limits based on subscription"""
        subscription = SubscriptionService.get_user_subscription(user_id)

        if not subscription or not subscription.plan:
            return {
                'scrapes_per_day': 5,
                'concurrent_jobs': 1,
                'data_retention_days': 7,
                'has_subscription': False
            }

        limits = subscription.plan.limits or {}
        return {
            'scrapes_per_day': limits.get('scrapes_per_day', 50),
            'concurrent_jobs': limits.get('concurrent_jobs', 1),
            'data_retention_days': limits.get('data_retention_days', 30),
            'has_subscription': True,
            'plan_name': subscription.plan.name_ar
        }

    @staticmethod
    def check_user_can_scrape(user_id: int) -> Dict[str, Any]:
        """Check if user can perform scraping"""
        from database import ScrapJob

        limits = SubscriptionService.get_user_limits(user_id)

        # Count today's scrapes
        today = datetime.utcnow().date()
        today_start = datetime.combine(today, datetime.min.time())
        today_scrapes = db_session.query(ScrapJob).filter(
            ScrapJob.user_id == user_id,
            ScrapJob.created_at >= today_start
        ).count()

        # Count active jobs
        active_jobs = db_session.query(ScrapJob).filter(
            ScrapJob.user_id == user_id,
            ScrapJob.status.in_(['running', 'pending'])
        ).count()

        can_scrape = (
            today_scrapes < limits['scrapes_per_day'] and
            active_jobs < limits['concurrent_jobs']
        )

        return {
            'can_scrape': can_scrape,
            'scrapes_today': today_scrapes,
            'scrapes_limit': limits['scrapes_per_day'],
            'active_jobs': active_jobs,
            'jobs_limit': limits['concurrent_jobs'],
            'has_subscription': limits['has_subscription'],
            'plan_name': limits.get('plan_name')
        }

    @staticmethod
    def get_available_plans() -> List[SubscriptionPlan]:
        """Get all active subscription plans"""
        return db_session.query(SubscriptionPlan).filter(
            SubscriptionPlan.is_active == True
        ).order_by(SubscriptionPlan.display_order).all()

    @staticmethod
    def create_subscription(
        user_id: int,
        plan_id: int,
        plan_type: str = 'monthly',
        price_paid: Decimal = None,
        payment_method: str = None,
        payment_reference: str = None,
        notes: str = None
    ) -> Optional[Subscription]:
        """Create a new subscription for user"""
        plan = db_session.query(SubscriptionPlan).filter(
            SubscriptionPlan.id == plan_id,
            SubscriptionPlan.is_active == True
        ).first()

        if not plan:
            logger.error(f"Plan not found: {plan_id}")
            return None

        # Calculate price based on plan type
        if plan_type == 'monthly':
            price = plan.price_monthly or Decimal('0')
        elif plan_type == 'quarterly':
            price = plan.price_quarterly or (plan.price_monthly * 3 * Decimal('0.9')) if plan.price_monthly else Decimal('0')
        elif plan_type == 'yearly':
            price = plan.price_yearly or (plan.price_monthly * 12 * Decimal('0.8')) if plan.price_monthly else Decimal('0')
        else:
            price = plan.price_monthly or Decimal('0')

        # Calculate duration
        duration_map = {
            'daily': 1,
            'monthly': 30,
            'quarterly': 90,
            'yearly': 365
        }
        days = duration_map.get(plan_type, 30)

        # Check for existing active subscription
        existing = SubscriptionService.get_user_subscription(user_id)
        start_date = datetime.utcnow()

        if existing:
            # Extend from current end date
            start_date = existing.end_date

        end_date = start_date + timedelta(days=days)

        subscription = Subscription(
            user_id=user_id,
            plan_id=plan_id,
            plan_type=plan_type,
            price_paid=price_paid or price,
            start_date=start_date,
            end_date=end_date,
            is_active=True,
            payment_method=payment_method,
            payment_reference=payment_reference,
            notes=notes
        )

        db_session.add(subscription)
        db_session.commit()

        logger.info(f"Subscription created for user {user_id}, plan {plan.name_ar}")
        return subscription

    @staticmethod
    def extend_subscription(subscription_id: int, days: int) -> Optional[Subscription]:
        """Extend an existing subscription"""
        subscription = db_session.query(Subscription).filter(
            Subscription.id == subscription_id
        ).first()

        if not subscription:
            return None

        subscription.end_date = subscription.end_date + timedelta(days=days)
        db_session.commit()

        logger.info(f"Subscription {subscription_id} extended by {days} days")
        return subscription

    @staticmethod
    def cancel_subscription(subscription_id: int) -> bool:
        """Cancel a subscription"""
        subscription = db_session.query(Subscription).filter(
            Subscription.id == subscription_id
        ).first()

        if not subscription:
            return False

        subscription.is_active = False
        db_session.commit()

        logger.info(f"Subscription {subscription_id} cancelled")
        return True

    @staticmethod
    def get_user_subscriptions_history(user_id: int) -> List[Subscription]:
        """Get user's subscription history"""
        return db_session.query(Subscription).filter(
            Subscription.user_id == user_id
        ).order_by(Subscription.created_at.desc()).all()

    @staticmethod
    def is_subscription_expiring_soon(user_id: int, days_threshold: int = 3) -> bool:
        """Check if user's subscription is expiring soon"""
        subscription = SubscriptionService.get_user_subscription(user_id)
        if not subscription:
            return False

        days_remaining = (subscription.end_date - datetime.utcnow()).days
        return 0 <= days_remaining <= days_threshold


# Singleton instance
subscription_service = SubscriptionService()