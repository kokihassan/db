"""
Data Cleaning Service
"""
import json
import csv
import io
from typing import Dict, List, Any, Optional
from datetime import datetime
from collections import defaultdict
from loguru import logger


class DataCleanerService:
    """Service for data cleaning and processing operations"""

    def __init__(self):
        self.supported_formats = ['csv', 'json', 'xlsx', 'txt']

    async def clean_data(self, data: Any, options: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Clean and process data

        Args:
            data: Raw data to clean
            options: Cleaning options (remove_duplicates, trim_spaces, etc.)

        Returns:
            Cleaned data and statistics
        """
        options = options or {}
        result = {
            'success': False,
            'cleaned_data': None,
            'stats': {},
            'error': None
        }

        try:
            # Parse data if string
            if isinstance(data, str):
                try:
                    data = json.loads(data)
                except json.JSONDecodeError:
                    # Try CSV format
                    data = self._parse_csv_data(data)

            if not isinstance(data, (list, dict)):
                result['error'] = 'Unsupported data format'
                return result

            # Apply cleaning operations
            cleaned = data

            # Remove duplicates
            if options.get('remove_duplicates', True):
                cleaned = self._remove_duplicates(cleaned)
                result['stats']['duplicates_removed'] = len(data) - len(cleaned) if isinstance(data, list) else 0

            # Trim spaces
            if options.get('trim_spaces', True):
                cleaned = self._trim_spaces(cleaned)
                result['stats']['spaces_trimmed'] = True

            # Remove empty values
            if options.get('remove_empty', False):
                cleaned = self._remove_empty_values(cleaned)
                result['stats']['empty_removed'] = True

            # Standardize format
            if options.get('standardize', True):
                cleaned = self._standardize_format(cleaned)
                result['stats']['standardized'] = True

            result['success'] = True
            result['cleaned_data'] = cleaned
            result['stats']['total_records'] = len(cleaned) if isinstance(cleaned, list) else 1

        except Exception as e:
            logger.error(f"Data cleaning error: {e}")
            result['error'] = str(e)

        return result

    def _remove_duplicates(self, data: List) -> List:
        """Remove duplicate records"""
        if not isinstance(data, list):
            return data

        seen = set()
        unique_data = []

        for item in data:
            if isinstance(item, dict):
                # Create hash from dict values
                item_key = json.dumps(item, sort_keys=True, ensure_ascii=False)
            else:
                item_key = str(item)

            if item_key not in seen:
                seen.add(item_key)
                unique_data.append(item)
            elif isinstance(item, dict):
                # For dicts, try to find unique key
                key_field = item.get('id') or item.get('url') or item.get('name')
                if key_field and key_field not in seen:
                    seen.add(key_field)
                    unique_data.append(item)

        return unique_data

    def _trim_spaces(self, data: Any) -> Any:
        """Trim whitespace from all string values"""
        if isinstance(data, str):
            return data.strip()
        elif isinstance(data, dict):
            return {k: self._trim_spaces(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._trim_spaces(item) for item in data]
        return data

    def _remove_empty_values(self, data: Any) -> Any:
        """Remove empty/null values"""
        if isinstance(data, dict):
            return {k: self._remove_empty_values(v) for k, v in data.items() if v not in [None, '', [], {}]}
        elif isinstance(data, list):
            return [self._remove_empty_values(item) for item in data if item not in [None, '', [], {}]]
        return data

    def _standardize_format(self, data: Any) -> Any:
        """Standardize data format (dates, numbers, etc.)"""
        if isinstance(data, dict):
            return {k: self._standardize_format(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._standardize_format(item) for item in data]
        elif isinstance(data, str):
            # Try to standardize common formats
            data = self._standardize_string(data)
        return data

    def _standardize_string(self, value: str) -> str:
        """Standardize a string value"""
        # Normalize Arabic text
        value = value.strip()
        # Fix common encoding issues
        value = value.replace('\r\n', '\n').replace('\r', '\n')
        return value

    async def export_data(self, data: Any, format: str = 'json') -> Dict[str, Any]:
        """
        Export data in specified format

        Args:
            data: Data to export
            format: Output format (json, csv, txt)

        Returns:
            Exported data as string and metadata
        """
        result = {
            'success': False,
            'data': None,
            'format': format,
            'error': None
        }

        try:
            if format == 'json':
                result['data'] = json.dumps(data, ensure_ascii=False, indent=2)
            elif format == 'csv':
                result['data'] = self._to_csv(data)
            elif format == 'txt':
                result['data'] = self._to_text(data)
            else:
                result['error'] = f'Unsupported format: {format}'
                return result

            result['success'] = True

        except Exception as e:
            logger.error(f"Export error: {e}")
            result['error'] = str(e)

        return result

    def _to_csv(self, data: List[Dict]) -> str:
        """Convert list of dicts to CSV string"""
        if not data:
            return ''

        output = io.StringIO()
        # Get all unique keys
        keys = set()
        for item in data:
            if isinstance(item, dict):
                keys.update(item.keys())

        keys = sorted(list(keys))
        writer = csv.DictWriter(output, fieldnames=keys)
        writer.writeheader()

        for item in data:
            if isinstance(item, dict):
                writer.writerow(item)

        return output.getvalue()

    def _to_text(self, data: Any) -> str:
        """Convert data to plain text"""
        if isinstance(data, list):
            lines = []
            for i, item in enumerate(data, 1):
                if isinstance(item, dict):
                    lines.append(f"--- Record {i} ---")
                    for k, v in item.items():
                        lines.append(f"{k}: {v}")
                else:
                    lines.append(str(item))
            return '\n'.join(lines)
        elif isinstance(data, dict):
            lines = []
            for k, v in data.items():
                lines.append(f"{k}: {v}")
            return '\n'.join(lines)
        return str(data)

    def _parse_csv_data(self, csv_str: str) -> List[Dict]:
        """Parse CSV string to list of dicts"""
        try:
            reader = csv.DictReader(io.StringIO(csv_str))
            return list(reader)
        except Exception as e:
            logger.error(f"CSV parsing error: {e}")
            return []

    async def filter_data(self, data: List[Dict], filters: Dict) -> List[Dict]:
        """
        Filter data based on criteria

        Args:
            data: List of records
            filters: Filter criteria {field: value} or {field: {operator: value}}

        Returns:
            Filtered data
        """
        if not isinstance(data, list):
            return data

        filtered = data

        for field, criteria in filters.items():
            if isinstance(criteria, dict):
                # Complex filter with operator
                operator = criteria.get('operator', 'eq')
                value = criteria.get('value')

                if operator == 'contains':
                    filtered = [r for r in filtered if r.get(field) and value.lower() in str(r[field]).lower()]
                elif operator == 'gt':
                    filtered = [r for r in filtered if r.get(field) and self._compare_values(r[field], value) > 0]
                elif operator == 'lt':
                    filtered = [r for r in filtered if r.get(field) and self._compare_values(r[field], value) < 0]
            else:
                # Simple equality filter
                filtered = [r for r in filtered if r.get(field) == criteria]

        return filtered

    def _compare_values(self, a: Any, b: Any) -> int:
        """Compare two values"""
        try:
            if isinstance(a, (int, float)) and isinstance(b, (int, float)):
                return (a > b) - (a < b)
            return (str(a) > str(b)) - (str(a) < str(b))
        except Exception:
            return 0


# Singleton instance
cleaner_service = DataCleanerService()