"""
OpenAI Service for AI Assistant
"""
import json
from typing import Dict, Any, Optional
from loguru import logger
from config import settings


class OpenAIService:
    """Service for OpenAI API integration"""

    def __init__(self):
        self.api_key = settings.OPENAI_API_KEY
        self.model = settings.OPENAI_MODEL
        self.client = None

    async def initialize(self):
        """Initialize OpenAI client"""
        try:
            from openai import AsyncOpenAI
            self.client = AsyncOpenAI(api_key=self.api_key)
            logger.info("OpenAI client initialized")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            self.client = None

    async def parse_user_intent(self, message: str) -> Dict[str, Any]:
        """
        Parse user message to extract intent and parameters

        Returns:
            {
                "action": "scrape|clean|schedule|report|help",
                "target": "url or data",
                "parameters": {},
                "confidence": 0.0-1.0
            }
        """
        if not self.client:
            return {"action": "error", "message": "AI service not available", "confidence": 0}

        prompt = f"""You are a smart scraping assistant. Parse user messages and return structured commands.

User message: "{message}"

Return JSON with:
- action: "scrape" (fetch data from url), "clean" (process/format data), "schedule" (set up recurring scrape), "report" (generate stats), "help" (show help), "subscribe" (subscription related), "contact" (get contact info)
- target: the URL or data mentioned
- parameters: any additional parameters (selectors, format, interval, etc.)
- confidence: 0.0 to 1.0 based on how sure you are

If the user is asking for scraping, try to extract the URL even if not explicitly stated.
If unclear, ask for clarification.

Examples:
- "عايز أرجع بيانات من موقع amazon" → {{"action": "scrape", "target": "https://www.amazon.com", "parameters": {{}}, "confidence": 0.9}}
- "نظف البيانات دي" → {{"action": "clean", "target": "provided_data", "parameters": {{}}, "confidence": 0.8}}
- "شوف الأشتركات" → {{"action": "subscribe", "target": "list_plans", "parameters": {{}}, "confidence": 0.95}}

Return ONLY valid JSON, no markdown or explanation."""

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that parses user commands for a data scraping bot. Always return valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=500
            )

            content = response.choices[0].message.content.strip()
            # Clean up potential markdown code blocks
            if content.startswith('```'):
                content = content.split('```')[1]
                if content.startswith('json'):
                    content = content[4:]
            result = json.loads(content.strip())
            return result

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON: {e}")
            return {"action": "error", "message": "Failed to understand request", "confidence": 0}
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return {"action": "error", "message": str(e), "confidence": 0}

    async def generate_response(self, message: str, context: Optional[Dict] = None) -> str:
        """Generate a conversational response"""
        if not self.client:
            return "خدمة الذكاء الاصطناعي غير متاحة حالياً."

        system_prompt = """You are a helpful assistant for a data scraping Telegram bot.
You help users with:
- Scraping data from websites
- Cleaning and formatting data
- Understanding their subscriptions
- General inquiries

Be friendly, concise, and helpful. If you don't understand something, ask for clarification.
Keep responses short since this is a Telegram bot."""

        messages = [{"role": "system", "content": system_prompt}]

        if context:
            context_str = f"Context: {json.dumps(context, ensure_ascii=False)}"
            messages.append({"role": "system", "content": context_str})

        messages.append({"role": "user", "content": message})

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.7,
                max_tokens=1000
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI response error: {e}")
            return "عذراً، حدث خطأ. يرجى المحاولة لاحقاً."

    async def suggest_selectors(self, url: str, description: str = "") -> Dict[str, Any]:
        """Suggest CSS selectors for a given URL and data description"""
        if not self.client:
            return {"error": "AI service not available"}

        prompt = f"""For the URL: {url}
And data needed: {description}

Suggest appropriate CSS selectors to extract the data. Return JSON with:
- selectors: list of CSS selectors
- xpath: alternative XPath selectors
- tips: any helpful tips for this site

Return ONLY valid JSON."""

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a web scraping expert. Return JSON with selector suggestions."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=500
            )

            content = response.choices[0].message.content.strip()
            if content.startswith('```'):
                content = content.split('```')[1]
                if content.startswith('json'):
                    content = content[4:]
            return json.loads(content.strip())

        except Exception as e:
            logger.error(f"Selector suggestion error: {e}")
            return {"error": str(e)}


# Singleton instance
openai_service = OpenAIService()