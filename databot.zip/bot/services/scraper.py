"""
Web Scraper Service
"""
import asyncio
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from urllib.parse import urlparse
import httpx
from bs4 import BeautifulSoup
from loguru import logger

from config import settings


class ScraperService:
    """Service for web scraping operations"""

    def __init__(self):
        self.timeout = settings.SCRAPE_TIMEOUT
        self.client = None

    async def initialize(self):
        """Initialize HTTP client"""
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout),
            follow_redirects=True,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        )

    async def close(self):
        """Close HTTP client"""
        if self.client:
            await self.client.aclose()

    async def scrape_url(self, url: str, selectors: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Scrape a single URL

        Args:
            url: The URL to scrape
            selectors: Optional CSS selectors for data extraction

        Returns:
            Dict with scraped data and metadata
        """
        if not self.client:
            await self.initialize()

        result = {
            'url': url,
            'success': False,
            'data': None,
            'error': None,
            'scraped_at': datetime.utcnow().isoformat()
        }

        try:
            # Validate URL
            if not self._is_valid_url(url):
                result['error'] = 'Invalid URL'
                return result

            # Fetch page
            response = await self.client.get(url)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, 'lxml')

            if selectors:
                # Extract specific data using selectors
                data = self._extract_with_selectors(soup, selectors)
            else:
                # Extract general data
                data = self._extract_general_data(soup, url)

            result['success'] = True
            result['data'] = data

            logger.info(f"Successfully scraped: {url}")

        except httpx.TimeoutException:
            result['error'] = 'Request timeout'
            logger.error(f"Timeout scraping: {url}")
        except httpx.HTTPStatusError as e:
            result['error'] = f'HTTP error: {e.response.status_code}'
            logger.error(f"HTTP error scraping {url}: {e}")
        except Exception as e:
            result['error'] = str(e)
            logger.error(f"Error scraping {url}: {e}")

        return result

    async def scrape_multiple(self, urls: List[str], selectors: Optional[Dict] = None) -> List[Dict]:
        """Scrape multiple URLs concurrently"""
        tasks = [self.scrape_url(url, selectors) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return [r if isinstance(r, dict) else {'error': str(r)} for r in results]

    def _extract_with_selectors(self, soup: BeautifulSoup, selectors: Dict) -> Dict:
        """Extract data using specified selectors"""
        data = {}
        for field_name, selector in selectors.items():
            elements = soup.select(selector)
            if len(elements) == 1:
                data[field_name] = elements[0].get_text(strip=True)
            else:
                data[field_name] = [el.get_text(strip=True) for el in elements]
        return data

    def _extract_general_data(self, soup: BeautifulSoup, url: str) -> Dict:
        """Extract general data from page"""
        data = {
            'title': soup.title.string if soup.title else None,
            'meta_description': None,
            'headings': [],
            'links': [],
            'images': [],
            'text_content': None
        }

        # Meta description
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc:
            data['meta_description'] = meta_desc.get('content', '')

        # Headings
        for tag in ['h1', 'h2', 'h3']:
            headings = soup.find_all(tag)
            data['headings'].extend([h.get_text(strip=True) for h in headings[:10]])

        # Links
        links = soup.find_all('a', href=True)
        data['links'] = [link['href'] for link in links[:50]]

        # Images
        images = soup.find_all('img')
        data['images'] = [
            {
                'src': img.get('src', ''),
                'alt': img.get('alt', '')
            }
            for img in images[:20] if img.get('src')
        ]

        # Text content (first 5000 chars)
        text = soup.get_text(separator='\n', strip=True)
        data['text_content'] = text[:5000]

        return data

    def _is_valid_url(self, url: str) -> bool:
        """Validate URL format"""
        try:
            result = urlparse(url)
            return all([result.scheme in ['http', 'https'], result.netloc])
        except Exception:
            return False

    async def test_selectors(self, url: str, selector: str) -> Dict[str, Any]:
        """Test a CSS selector on a page"""
        result = await self.scrape_url(url)
        if not result['success']:
            return {'error': result['error'], 'matches': []}

        soup = BeautifulSoup(result['data']['text_content'], 'lxml')
        elements = soup.select(selector)

        return {
            'matches': len(elements),
            'preview': [el.get_text(strip=True)[:100] for el in elements[:5]]
        }


# Singleton instance
scraper_service = ScraperService()