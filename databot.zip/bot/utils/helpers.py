"""
Bot Utilities
"""
import re
from typing import Optional, List, Dict
from datetime import datetime
from urllib.parse import urlparse


def is_valid_url(url: str) -> bool:
    """Check if string is a valid URL"""
    try:
        result = urlparse(url)
        return all([result.scheme in ['http', 'https'], result.netloc])
    except Exception:
        return False


def extract_urls(text: str) -> List[str]:
    """Extract all URLs from text"""
    url_pattern = r'https?://[^\s]+'
    return re.findall(url_pattern, text)


def format_datetime(dt: Optional[datetime], format: str = '%Y-%m-%d %H:%M') -> str:
    """Format datetime to string"""
    if not dt:
        return '-'
    return dt.strftime(format)


def truncate_text(text: str, max_length: int = 100, suffix: str = '...') -> str:
    """Truncate text to max length"""
    if not text or len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def clean_phone_number(phone: str) -> str:
    """Clean phone number for storage"""
    # Remove all non-digit characters
    digits = re.sub(r'\D', '', phone)
    # Add country code if missing
    if len(digits) == 10:
        digits = '20' + digits
    elif len(digits) == 11 and digits.startswith('0'):
        digits = '2' + digits
    return digits


def parse_interval(interval: str) -> Optional[str]:
    """Parse interval string to standard format"""
    interval = interval.lower().strip()

    if interval in ['hourly', 'ساعوي', 'ساعة', 'hour']:
        return 'hourly'
    elif interval in ['daily', 'يومي', 'يوم', 'day']:
        return 'daily'
    elif interval in ['weekly', 'أسبوعي', 'أسبوع', 'week']:
        return 'weekly'
    elif interval in ['monthly', 'شهري', 'شهر', 'month']:
        return 'monthly'

    return None


def format_price(amount: float, currency: str = '$') -> str:
    """Format price for display"""
    return f"{amount:.2f} {currency}"


def format_file_size(size_bytes: int) -> str:
    """Format file size for display"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"


def parse_duration(duration_str: str) -> Optional[int]:
    """Parse duration string to days"""
    duration_str = duration_str.lower().strip()

    # Match patterns like "30 days", "شهر", "سنة"
    if 'year' in duration_str or 'سنة' in duration_str or 'سنوي' in duration_str:
        return 365
    elif 'month' in duration_str or 'شهر' in duration_str:
        return 30
    elif 'week' in duration_str or 'أسبوع' in duration_str:
        return 7
    elif 'day' in duration_str or 'يوم' in duration_str:
        # Extract number
        match = re.search(r'\d+', duration_str)
        return int(match.group()) if match else None

    return None


def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe storage"""
    # Remove invalid characters
    filename = re.sub(r'[<>:"/\\|?*]', '', filename)
    # Replace spaces with underscores
    filename = re.sub(r'\s+', '_', filename)
    # Limit length
    return filename[:255]


def escape_markdown(text: str) -> str:
    """Escape special characters for Telegram Markdown"""
    escape_chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    for char in escape_chars:
        text = text.replace(char, f'\\{char}')
    return text


def build_keyboard(buttons: List[List[str]], row_width: int = 2) -> List[List[Dict]]:
    """Build inline keyboard from button list"""
    from telegram import InlineKeyboardButton
    keyboard = []
    row = []

    for i, button in enumerate(buttons):
        row.append(InlineKeyboardButton(button, callback_data=f"btn_{i}"))

        if len(row) >= row_width:
            keyboard.append(row)
            row = []

    if row:
        keyboard.append(row)

    return keyboard