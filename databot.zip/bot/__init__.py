"""
Bot Package
"""
from .main import bot, main

__all__ = ['bot', 'main']