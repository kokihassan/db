# -*- coding: utf-8 -*-
"""
Flask Admin Dashboard Application
"""
import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_admin import Admin, AdminIndexView, expose
from flask_admin.contrib.sqla import ModelView
from werkzeug.security import check_password_hash
from loguru import logger

from config import settings
from database import db_session, init_db
from database.models import User, Subscription, SubscriptionPlan, ScrapJob, ScrapedData, Config, ActivityLog


# Create Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = settings.SECRET_KEY
app.config['SQLALCHEMY_DATABASE_URI'] = settings.DATABASE_URL
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


# Models
@login_manager.user_loader
def load_user(user_id):
    return db_session.query(User).get(int(user_id))


# Views
class DashboardView(AdminIndexView):
    @expose('/')
    @login_required
    def index(self):
        # Get statistics
        total_users = db_session.query(User).count()
        active_subs = db_session.query(Subscription).filter(Subscription.is_active == True).count()
        total_jobs = db_session.query(ScrapJob).count()
        completed_jobs = db_session.query(ScrapJob).filter(ScrapJob.status == 'completed').count()

        # Get recent activity
        recent_logs = db_session.query(ActivityLog).order_by(
            ActivityLog.created_at.desc()
        ).limit(10).all()

        return self.render('admin/dashboard.html',
                           total_users=total_users,
                           active_subs=active_subs,
                           total_jobs=total_jobs,
                           completed_jobs=completed_jobs,
                           recent_logs=recent_logs)


class AdminModelView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin


# Admin setup - Create AFTER defining views
admin = Admin(app, name='DataBot Admin', template_mode='bootstrap5', index_view=DashboardView(name='Dashboard', url='/'))


# Register views
admin.add_view(AdminModelView(User, db_session, category='Users', name='Users'))
admin.add_view(AdminModelView(Subscription, db_session, category='Users', name='Subscriptions'))
admin.add_view(AdminModelView(SubscriptionPlan, db_session, category='Users', name='Plans'))


# Routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('admin.index'))

    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == settings.ADMIN_USERNAME and password == settings.ADMIN_PASSWORD:
            # Create admin user if not exists
            admin_user = db_session.query(User).filter(User.is_admin == True).first()
            if not admin_user:
                admin_user = User(
                    telegram_id=0,
                    username='admin',
                    first_name='Admin',
                    is_admin=True,
                    is_active=True
                )
                db_session.add(admin_user)
                db_session.commit()

            login_user(admin_user)
            return redirect(url_for('admin.index'))
        else:
            error = 'Invalid credentials'

    return render_template('admin/login.html', error=error)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


# Users Management
@app.route('/admin/users')
@login_required
def admin_users():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    search = request.args.get('search', '')

    query = db_session.query(User)
    if search:
        query = query.filter(
            User.username.ilike(f'%{search}%') |
            User.first_name.ilike(f'%{search}%')
        )

    users = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return render_template('admin/users.html', users=users, search=search)


@app.route('/admin/users/<int:user_id>')
@login_required
def admin_user_detail(user_id):
    user = db_session.query(User).get_or_404(user_id)
    jobs = db_session.query(ScrapJob).filter(ScrapJob.user_id == user_id).order_by(
        ScrapJob.created_at.desc()
    ).limit(20).all()
    subscriptions = db_session.query(Subscription).filter(
        Subscription.user_id == user_id
    ).order_by(Subscription.created_at.desc()).all()

    return render_template('admin/user_detail.html', user=user, jobs=jobs, subscriptions=subscriptions)


@app.route('/admin/users/<int:user_id>/toggle-active', methods=['POST'])
@login_required
def admin_toggle_user_active(user_id):
    user = db_session.query(User).get_or_404(user_id)
    user.is_active = not user.is_active
    db_session.commit()

    action = 'activate_user' if user.is_active else 'deactivate_user'
    log = ActivityLog(user_id=user_id, action=action, details={'is_active': user.is_active})
    db_session.add(log)
    db_session.commit()

    return jsonify({'success': True, 'is_active': user.is_active})


# Subscriptions Management
@app.route('/admin/subscriptions')
@login_required
def admin_subscriptions():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    status = request.args.get('status', 'all')

    query = db_session.query(Subscription)
    if status == 'active':
        query = query.filter(Subscription.is_active == True)
    elif status == 'expired':
        query = query.filter(Subscription.is_active == False)

    subscriptions = query.order_by(Subscription.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return render_template('admin/subscriptions.html', subscriptions=subscriptions, status=status)


@app.route('/admin/subscriptions/create', methods=['GET', 'POST'])
@login_required
def admin_create_subscription():
    if request.method == 'POST':
        user_id = request.form.get('user_id', type=int)
        plan_id = request.form.get('plan_id', type=int)
        plan_type = request.form.get('plan_type', 'monthly')
        payment_method = request.form.get('payment_method', '')
        notes = request.form.get('notes', '')

        from bot.services import subscription_service
        sub = subscription_service.create_subscription(
            user_id=user_id,
            plan_id=plan_id,
            plan_type=plan_type,
            payment_method=payment_method,
            notes=notes
        )

        if sub:
            flash('Subscription created successfully', 'success')
            log = ActivityLog(
                action='create_subscription',
                entity_type='subscription',
                entity_id=sub.id,
                details={'user_id': user_id, 'plan_id': plan_id}
            )
            db_session.add(log)
            db_session.commit()
        else:
            flash('Failed to create subscription', 'error')

        return redirect(url_for('admin_subscriptions'))

    plans = db_session.query(SubscriptionPlan).filter(SubscriptionPlan.is_active == True).all()
    return render_template('admin/create_subscription.html', plans=plans)


# Subscription Plans
@app.route('/admin/plans')
@login_required
def admin_plans():
    plans = db_session.query(SubscriptionPlan).order_by(SubscriptionPlan.display_order).all()
    return render_template('admin/plans.html', plans=plans)


@app.route('/admin/plans/create', methods=['GET', 'POST'])
@login_required
def admin_create_plan():
    if request.method == 'POST':
        name_ar = request.form.get('name_ar')
        name_en = request.form.get('name_en')
        description = request.form.get('description', '')
        price_monthly = request.form.get('price_monthly', type=float)
        price_quarterly = request.form.get('price_quarterly', type=float)
        price_yearly = request.form.get('price_yearly', type=float)
        features = request.form.get('features', '')
        display_order = request.form.get('display_order', 0, type=int)

        # Parse features
        features_list = [f.strip() for f in features.split('\n') if f.strip()]
        features_json = {'items': features_list}

        plan = SubscriptionPlan(
            name_ar=name_ar,
            name_en=name_en,
            description=description,
            price_monthly=price_monthly,
            price_quarterly=price_quarterly,
            price_yearly=price_yearly,
            features=features_json,
            display_order=display_order
        )

        db_session.add(plan)
        db_session.commit()

        flash('Plan created successfully', 'success')
        return redirect(url_for('admin_plans'))

    return render_template('admin/create_plan.html')


@app.route('/admin/plans/<int:plan_id>/edit', methods=['GET', 'POST'])
@login_required
def admin_edit_plan(plan_id):
    plan = db_session.query(SubscriptionPlan).get_or_404(plan_id)

    if request.method == 'POST':
        plan.name_ar = request.form.get('name_ar')
        plan.name_en = request.form.get('name_en')
        plan.description = request.form.get('description', '')
        plan.price_monthly = request.form.get('price_monthly', type=float)
        plan.price_quarterly = request.form.get('price_quarterly', type=float)
        plan.price_yearly = request.form.get('price_yearly', type=float)
        plan.is_active = 'is_active' in request.form
        plan.display_order = request.form.get('display_order', 0, type=int)

        features = request.form.get('features', '')
        features_list = [f.strip() for f in features.split('\n') if f.strip()]
        plan.features = {'items': features_list}

        db_session.commit()
        flash('Plan updated successfully', 'success')
        return redirect(url_for('admin_plans'))

    return render_template('admin/edit_plan.html', plan=plan)


# Scraping Jobs
@app.route('/admin/scraping/jobs')
@login_required
def admin_scraping_jobs():
    page = request.args.get('page', 1, type=int)
    per_page = 30
    status = request.args.get('status', 'all')
    user_id = request.args.get('user_id', type=int)

    query = db_session.query(ScrapJob)
    if status != 'all':
        query = query.filter(ScrapJob.status == status)
    if user_id:
        query = query.filter(ScrapJob.user_id == user_id)

    jobs = query.order_by(ScrapJob.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return render_template('admin/scraping_jobs.html', jobs=jobs, status=status)


@app.route('/admin/scraping/jobs/<int:job_id>')
@login_required
def admin_scraping_job_detail(job_id):
    job = db_session.query(ScrapJob).get_or_404(job_id)
    data = db_session.query(ScrapedData).filter(ScrapedData.job_id == job_id).all()

    return render_template('admin/scraping_job_detail.html', job=job, data=data)


# Text Content Management
@app.route('/admin/texts')
@login_required
def admin_texts():
    category = request.args.get('category', 'all')
    query = db_session.query(Config)

    if category != 'all':
        query = query.filter(Config.category == category)

    configs = query.order_by(Config.category, Config.config_key).all()

    # Group by category
    categories = {}
    for config in configs:
        cat = config.category or 'other'
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(config)

    return render_template('admin/texts.html', categories=categories, current_category=category)


@app.route('/admin/texts/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
def admin_edit_text(config_id):
    config = db_session.query(Config).get_or_404(config_id)

    if request.method == 'POST':
        config.config_value = request.form.get('config_value')
        config.updated_by = current_user.id if hasattr(current_user, 'id') else None
        config.updated_at = datetime.utcnow()
        db_session.commit()

        # Log activity
        log = ActivityLog(
            action='update_text',
            entity_type='config',
            entity_id=config.id,
            details={'key': config.config_key}
        )
        db_session.add(log)
        db_session.commit()

        flash('Text updated successfully', 'success')
        return redirect(url_for('admin_texts'))

    return render_template('admin/edit_text.html', config=config)


@app.route('/admin/texts/create', methods=['GET', 'POST'])
@login_required
def admin_create_text():
    if request.method == 'POST':
        config_key = request.form.get('config_key')
        config_value = request.form.get('config_value')
        config_type = request.form.get('config_type', 'text')
        category = request.form.get('category', 'bot_text')
        description = request.form.get('description', '')

        # Check if key exists
        existing = db_session.query(Config).filter(Config.config_key == config_key).first()
        if existing:
            flash('This key already exists', 'error')
            return redirect(url_for('admin_create_text'))

        config = Config(
            config_key=config_key,
            config_value=config_value,
            config_type=config_type,
            category=category,
            description=description
        )

        db_session.add(config)
        db_session.commit()

        flash('Text created successfully', 'success')
        return redirect(url_for('admin_texts'))

    return render_template('admin/create_text.html')


# Settings
@app.route('/admin/settings', methods=['GET', 'POST'])
@login_required
def admin_settings():
    if request.method == 'POST':
        # Update admin password
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        if current_password and new_password:
            if current_password != settings.ADMIN_PASSWORD:
                flash('Current password is incorrect', 'error')
                return redirect(url_for('admin_settings'))

            if new_password != confirm_password:
                flash('New password does not match', 'error')
                return redirect(url_for('admin_settings'))

            # Update in .env file
            env_path = os.path.join(os.path.dirname(__file__), '.env')
            if os.path.exists(env_path):
                with open(env_path, 'r') as f:
                    lines = f.readlines()

                with open(env_path, 'w') as f:
                    for line in lines:
                        if line.startswith('ADMIN_PASSWORD='):
                            f.write(f'ADMIN_PASSWORD={new_password}\n')
                        else:
                            f.write(line)

            flash('Password changed successfully', 'success')

        return redirect(url_for('admin_settings'))

    return render_template('admin/settings.html')


# Activity Logs
@app.route('/admin/logs')
@login_required
def admin_logs():
    page = request.args.get('page', 1, type=int)
    per_page = 50
    action = request.args.get('action', 'all')

    query = db_session.query(ActivityLog)
    if action != 'all':
        query = query.filter(ActivityLog.action == action)

    logs = query.order_by(ActivityLog.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    # Get distinct actions for filter
    actions = db_session.query(ActivityLog.action).distinct().all()

    return render_template('admin/logs.html', logs=logs, actions=actions, current_action=action)


# Reports
@app.route('/admin/reports')
@login_required
def admin_reports():
    # User stats
    total_users = db_session.query(User).count()
    active_users = db_session.query(User).filter(User.is_active == True).count()

    # Subscription stats
    active_subs = db_session.query(Subscription).filter(Subscription.is_active == True).count()
    total_subs = db_session.query(Subscription).count()

    # Scraping stats
    total_jobs = db_session.query(ScrapJob).count()
    completed_jobs = db_session.query(ScrapJob).filter(ScrapJob.status == 'completed').count()
    failed_jobs = db_session.query(ScrapJob).filter(ScrapJob.status == 'failed').count()

    # Revenue (if price_paid is set)
    from sqlalchemy import func
    revenue = db_session.query(func.sum(Subscription.price_paid)).filter(
        Subscription.is_active == True
    ).scalar() or 0

    return render_template('admin/reports.html',
                           total_users=total_users,
                           active_users=active_users,
                           active_subs=active_subs,
                           total_subs=total_subs,
                           total_jobs=total_jobs,
                           completed_jobs=completed_jobs,
                           failed_jobs=failed_jobs,
                           revenue=float(revenue))


# API Endpoints
@app.route('/api/stats')
@login_required
def api_stats():
    from sqlalchemy import func

    stats = {
        'users': db_session.query(User).count(),
        'active_users': db_session.query(User).filter(User.is_active == True).count(),
        'subscriptions': db_session.query(Subscription).filter(Subscription.is_active == True).count(),
        'jobs': db_session.query(ScrapJob).count(),
        'completed_jobs': db_session.query(ScrapJob).filter(ScrapJob.status == 'completed').count(),
    }

    return jsonify(stats)


# Error handlers
@app.errorhandler(404)
def not_found(e):
    return render_template('admin/404.html'), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('admin/500.html'), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
