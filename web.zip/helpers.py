# ============================================================
#  Helpers - نسخة محسّنة
# ============================================================

import shutil
import requests
import math
import os
import time
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import FINISHED_PROGRESS_STR, UN_FINISHED_PROGRESS_STR
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions


async def progress_bar(current, total):
    if total == 0:
        return FINISHED_PROGRESS_STR * 10, "100.00"
    percentage      = current / total
    finished_length = int(percentage * 10)
    progress        = f"{FINISHED_PROGRESS_STR * finished_length}{UN_FINISHED_PROGRESS_STR * (10 - finished_length)}"
    return progress, f"{percentage * 100:.2f}"


async def progress_for_pyrogram(current, total, ud_type, message, start):
    reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("🚫 إلغاء", callback_data="cdstoptrasmission")]])
    now  = time.time()
    diff = now - start
    if round(diff % 10.00) == 0 or current == total:
        percentage = current * 100 / total
        speed      = current / diff if diff > 0 else 0
        elapsed    = round(diff) * 1000
        eta        = round((total - current) / speed) * 1000 if speed > 0 else 0
        progress   = "[{0}{1}]\n📊 **{2}%**\n".format(
            "■" * math.floor(percentage / 5),
            "□" * (20 - math.floor(percentage / 5)),
            round(percentage, 2)
        )
        tmp = (
            progress
            + "✅ **تم:** {0}\n📁 **الحجم:** {1}\n🚀 **السرعة:** {2}/s\n⌚ **الوقت المتبقي:** {3}".format(
                humanbytes(current), humanbytes(total),
                humanbytes(speed),
                TimeFormatter(eta) or "0 s"
            )
        )
        try:
            await message.edit(text=f"{ud_type}\n{tmp}", reply_markup=reply_markup)
        except:
            pass


def humanbytes(size):
    if not size:
        return "0 B"
    power    = 2 ** 10
    n        = 0
    labels   = {0: "B", 1: "KiB", 2: "MiB", 3: "GiB", 4: "TiB"}
    while size > power and n < 4:
        size /= power
        n += 1
    return f"{size:.2f} {labels[n]}"


def TimeFormatter(milliseconds: int) -> str:
    seconds, _ = divmod(int(milliseconds), 1000)
    minutes, s = divmod(seconds, 60)
    hours, m   = divmod(minutes, 60)
    days, h    = divmod(hours, 24)
    parts = []
    if days:    parts.append(f"{days}d")
    if h:       parts.append(f"{h}h")
    if m:       parts.append(f"{m}m")
    if s:       parts.append(f"{s}s")
    return " ".join(parts)


async def download_image(base_url, image_url, idx):
    try:
        if not image_url.startswith(("http:", "https:")):
            from urllib.parse import urljoin
            image_url = urljoin(base_url, image_url)
        headers = {"User-Agent": "Mozilla/5.0", "Referer": base_url}
        r = requests.get(image_url, stream=True, headers=headers, timeout=10)
        r.raise_for_status()
        fname = f"_tmp_img_{idx}.jpg"
        with open(fname, "wb") as f:
            shutil.copyfileobj(r.raw, f)
        with open(fname, "rb") as f:
            data = f.read()
        os.remove(fname)
        return data
    except Exception as e:
        print(f"[download_image] {e}")
        return None


async def download_media(base_url, media_url, idx, media_type):
    try:
        if not media_url.startswith(("http:", "https:")):
            from urllib.parse import urljoin
            media_url = urljoin(base_url, media_url)
        headers = {"User-Agent": "Mozilla/5.0", "Referer": base_url}
        with requests.get(media_url, stream=True, headers=headers, timeout=20) as r:
            r.raise_for_status()
            filename = os.path.basename(media_url.split("?")[0]) or f"{media_type}{idx}"
            local_fn  = f"_tmp_{media_type}_{idx}_{filename}"
            with open(local_fn, "wb") as f:
                shutil.copyfileobj(r.raw, f)
            with open(local_fn, "rb") as f:
                data = f.read()
            os.remove(local_fn)
            return data, filename
    except Exception as e:
        print(f"[download_media] {e}")
        return None


async def download_pdf(base_url, pdf_url, idx, media_type):
    try:
        if not pdf_url.startswith(("http:", "https:")):
            from urllib.parse import urljoin
            pdf_url = urljoin(base_url, pdf_url)
        r = requests.get(pdf_url, stream=True, timeout=20)
        r.raise_for_status()
        fname = f"_tmp_pdf_{idx}.pdf"
        with open(fname, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
        with open(fname, "rb") as f:
            data = f.read()
        os.remove(fname)
        return data
    except Exception as e:
        print(f"[download_pdf] {e}")
        return None


async def init_headless_browser(url):
    # جرب Chrome أولاً
    try:
        opts = ChromeOptions()
        opts.add_argument("--headless")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-gpu")
        opts.add_argument("--window-size=1920,1080")
        driver = webdriver.Chrome(options=opts)
        driver.get(url)
        return driver
    except Exception as e_chrome:
        print(f"[Chrome] {e_chrome}")
    # جرب Firefox كبديل
    try:
        opts = FirefoxOptions()
        opts.add_argument("--headless")
        driver = webdriver.Firefox(options=opts)
        driver.get(url)
        return driver
    except Exception as e_ff:
        print(f"[Firefox] {e_ff}")
    return None
