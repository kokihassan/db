# ============================================================
#  WebScrapper Bot - Main
#  © BugHunterCodeLabs | Edited with full features
# ============================================================

import os
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from dotenv import load_dotenv

from config import START_TEXT, CONTACT_TEXT, ADMINS, PLANS
from utils import START_BUTTON, get_options_keyboard, get_plans_keyboard, get_plans_text
from database import register_user, get_user, set_plan, can_use, increment_usage, can_use_feature, get_all_users
from scraper import (
    all_audio_scraping, all_images_scraping, all_links_scraping,
    all_paragraph_scraping, all_pdf_scraping, all_video_scraping,
    extract_cookies, extract_local_storage, html_data_scraping,
    raw_data_scraping, extract_metadata, capture_screenshot, record_screen
)
from crawler import crawl_web

load_dotenv()

bot_token = os.getenv("BOT_TOKEN")
api_id    = os.getenv("API_ID")
api_hash  = os.getenv("API_HASH")
CRAWL_LOG_CHANNEL = os.getenv("CRAWL_LOG_CHANNEL")

if not all([bot_token, api_id, api_hash]):
    raise ValueError("❌ يجب ضبط BOT_TOKEN و API_ID و API_HASH في ملف .env")

app = Client("WebScrapperBot", bot_token=bot_token, api_id=int(api_id), api_hash=api_hash)


# ─────────────────────────── /start ───────────────────────────
@app.on_message(filters.command("start"))
async def start(_, message: Message):
    user_id  = message.from_user.id
    username = message.from_user.username or ""
    register_user(user_id, username)
    await message.reply_text(
        START_TEXT, disable_web_page_preview=True,
        quote=True, reply_markup=START_BUTTON
    )


# ─────────────────────────── /plans ───────────────────────────
@app.on_message(filters.command("plans"))
async def plans_cmd(_, message: Message):
    await message.reply_text(
        get_plans_text(), disable_web_page_preview=True,
        quote=True, reply_markup=get_plans_keyboard()
    )


# ─────────────────────────── /contact ─────────────────────────
@app.on_message(filters.command("contact"))
async def contact_cmd(_, message: Message):
    await message.reply_text(CONTACT_TEXT, quote=True)


# ─────────────────────────── /myplan ──────────────────────────
@app.on_message(filters.command("myplan"))
async def myplan_cmd(_, message: Message):
    user_id = message.from_user.id
    register_user(user_id, message.from_user.username or "")
    user = get_user(user_id)
    if not user:
        return await message.reply_text("⚠️ حدث خطأ، حاول مرة أخرى.")
    plan_key  = user["plan"]
    plan      = PLANS.get(plan_key, PLANS["free"])
    limit     = plan["limit"]
    limit_txt = "غير محدود ♾️" if limit == -1 else f"{user['daily_count']}/{limit} طلب اليوم"
    expiry    = user["expiry"] or "مستمر"
    text = (
        f"📊 **معلومات حسابك:**\n\n"
        f"👤 المعرف: `{user_id}`\n"
        f"📦 الباقة: **{plan['name']}**\n"
        f"📅 تنتهي في: `{expiry}`\n"
        f"📈 الاستخدام: {limit_txt}\n\n"
        f"لتغيير باقتك: /plans"
    )
    await message.reply_text(text, quote=True)


# ─────────────────────────── /admin ───────────────────────────
@app.on_message(filters.command("admin") & filters.user(ADMINS))
async def admin_cmd(_, message: Message):
    parts = message.text.split()
    # /admin setplan @username plan days
    if len(parts) >= 4 and parts[1] == "setplan":
        target   = parts[2].replace("@", "")
        plan_key = parts[3]
        days     = int(parts[4]) if len(parts) > 4 else 30
        users    = get_all_users()
        found    = next((u for u in users if u[1] == target), None)
        if not found:
            return await message.reply_text(f"❌ مش لاقي المستخدم @{target}")
        if plan_key not in PLANS:
            return await message.reply_text(f"❌ الباقة '{plan_key}' مش موجودة. المتاح: {', '.join(PLANS.keys())}")
        set_plan(found[0], plan_key, days)
        await message.reply_text(f"✅ تم تفعيل باقة **{PLANS[plan_key]['name']}** للمستخدم @{target} لمدة {days} يوم")

    # /admin users
    elif len(parts) >= 2 and parts[1] == "users":
        users = get_all_users()
        text  = f"👥 **إجمالي المستخدمين: {len(users)}**\n\n"
        for u in users[:20]:
            text += f"• @{u[1] or u[0]} | {u[2]} | انتهاء: {u[3] or 'مستمر'} | اليوم: {u[4]}\n"
        await message.reply_text(text)

    else:
        await message.reply_text(
            "⚙️ **أوامر الأدمن:**\n\n"
            "`/admin setplan @username plan days`\n"
            "  مثال: `/admin setplan @john pro 30`\n\n"
            "`/admin users` - عرض المستخدمين\n\n"
            f"**الباقات:** {', '.join(PLANS.keys())}"
        )


# ─────────────────────────── الروابط ──────────────────────────
@app.on_message(
    (filters.regex("https") | filters.regex("http") | filters.regex("www"))
    & filters.private
)
async def scrapping(_, message: Message):
    user_id  = message.from_user.id
    username = message.from_user.username or ""
    register_user(user_id, username)

    allowed, reason = can_use(user_id)
    if not allowed:
        return await message.reply_text(f"🚫 {reason}", quote=True)

    user     = get_user(user_id)
    plan_key = user["plan"] if user else "free"
    allowed_features = PLANS.get(plan_key, PLANS["free"])["allowed_features"]

    reply_markup = get_options_keyboard(allowed_features)
    await message.reply_text("🔍 اختر العملية:", reply_markup=reply_markup, quote=True,
                              disable_web_page_preview=True)


# ─────────────────────────── Callbacks ────────────────────────
@app.on_callback_query()
async def cb_data(bot: Client, update):
    user_id = update.from_user.id
    data    = update.data

    # ── الباقات ──
    if data == "cbplans":
        await update.message.edit_text(get_plans_text(), reply_markup=get_plans_keyboard())
        return

    if data.startswith("cbplan_"):
        plan_key = data.split("_", 1)[1]
        plan     = PLANS.get(plan_key)
        if not plan:
            return await update.answer("❌ الباقة غير موجودة")
        price_txt = "مجاني" if plan["price"] == 0 else f"${plan['price']}/{plan['period']}"
        await update.message.reply_text(
            f"📦 **{plan['name']}** - {price_txt}\n\n"
            f"للاشتراك تواصل مع الدعم:\n{CONTACT_TEXT}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📞 تواصل الآن", callback_data="cbcontact")
            ]])
        )
        return

    # ── التواصل ──
    if data == "cbcontact":
        await update.message.reply_text(CONTACT_TEXT)
        return

    # ── حسابي ──
    if data == "cbmyplan":
        user     = get_user(user_id)
        plan_key = user["plan"] if user else "free"
        plan     = PLANS.get(plan_key, PLANS["free"])
        limit    = plan["limit"]
        limit_txt = "غير محدود ♾️" if limit == -1 else f"{user['daily_count']}/{limit} طلب اليوم"
        expiry   = user["expiry"] or "مستمر"
        await update.message.reply_text(
            f"📊 **باقتك:** {plan['name']}\n"
            f"📅 **تنتهي:** {expiry}\n"
            f"📈 **الاستخدام:** {limit_txt}\n\n"
            f"لتغيير الباقة: /plans"
        )
        return

    # ── رجوع ──
    if data == "cbback":
        await update.message.edit_text(
            START_TEXT, disable_web_page_preview=True, reply_markup=START_BUTTON
        )
        return

    # ── التحقق من الاشتراك قبل كل العمليات ──
    allowed, reason = can_use(user_id)
    if not allowed:
        await update.answer(reason, show_alert=True)
        return

    # ── تنفيذ العمليات ──
    feature_map = {
        "cbrdata":          ("rawData",      raw_data_scraping,      None),
        "cbhtmldata":       ("htmlData",     html_data_scraping,     None),
        "cballlinks":       ("allLinks",     all_links_scraping,     None),
        "cballparagraphs":  ("allParagraphs",all_paragraph_scraping, None),
        "cballimages":      ("allImages",    all_images_scraping,    bot),
        "cballaudio":       ("allAudio",     all_audio_scraping,     bot),
        "cballvideo":       ("allVideo",     all_video_scraping,     bot),
        "cballpdf":         ("allPdf",       all_pdf_scraping,       None),
        "cbcookies":        ("cookies",      extract_cookies,        None),
        "cblocalstorage":   ("localStorage", extract_local_storage,  None),
        "cbmetadata":       ("metadata",     extract_metadata,       None),
        "cbscreenshot":     ("screenshot",   capture_screenshot,     None),
        "cbscreenrecord":   ("screenRecord", record_screen,          None),
        "cbcrawl":          ("crawlWeb",     None,                   bot),
    }

    if data in feature_map:
        feature_key, func, extra = feature_map[data]

        if not can_use_feature(user_id, feature_key):
            await update.answer(
                "🔒 هذه الميزة غير متاحة في باقتك الحالية.\nارفع الباقة عبر /plans",
                show_alert=True
            )
            return

        increment_usage(user_id)

        if data == "cbcrawl":
            if CRAWL_LOG_CHANNEL:
                await crawl_web(bot, update)
            else:
                await update.message.reply("⚠️ يجب ضبط CRAWL_LOG_CHANNEL في .env")
        elif extra:
            await func(extra, update)
        else:
            await func(update)

    elif data == "cdstoptrasmission":
        bot.stop_transmission()


app.run(print("✅ Bot is running..."))
