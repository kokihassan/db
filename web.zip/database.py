# ============================================================
#  نظام الاشتراكات - SQLite Database
# ============================================================

import sqlite3
from datetime import datetime, timedelta
from config import PLANS

DB_FILE = "subscriptions.db"


def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS subscriptions (
            user_id     INTEGER PRIMARY KEY,
            username    TEXT,
            plan        TEXT    DEFAULT 'free',
            expiry      TEXT    DEFAULT NULL,
            daily_count INTEGER DEFAULT 0,
            last_reset  TEXT    DEFAULT NULL,
            created_at  TEXT    DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def get_user(user_id: int) -> dict:
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return {
            "user_id": row[0], "username": row[1], "plan": row[2],
            "expiry": row[3], "daily_count": row[4],
            "last_reset": row[5], "created_at": row[6],
        }
    return None


def register_user(user_id: int, username: str):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO subscriptions (user_id, username)
        VALUES (?, ?)
    """, (user_id, username or ""))
    conn.commit()
    conn.close()


def set_plan(user_id: int, plan: str, days: int = 30):
    expiry = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d") if plan != "free" else None
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
        UPDATE subscriptions SET plan=?, expiry=?, daily_count=0
        WHERE user_id=?
    """, (plan, expiry, user_id))
    conn.commit()
    conn.close()


def is_plan_valid(user_id: int) -> bool:
    user = get_user(user_id)
    if not user or user["plan"] == "free":
        return True
    if user["expiry"] is None:
        return True
    try:
        expiry_date = datetime.strptime(user["expiry"], "%Y-%m-%d")
        if datetime.now() > expiry_date:
            # انتهى الاشتراك - رجّع للمجاني
            conn = sqlite3.connect(DB_FILE)
            conn.execute("UPDATE subscriptions SET plan='free', expiry=NULL WHERE user_id=?", (user_id,))
            conn.commit()
            conn.close()
            return False
    except:
        pass
    return True


def can_use(user_id: int) -> tuple[bool, str]:
    """بيرجع (مسموح, سبب المنع)"""
    user = get_user(user_id)
    if not user:
        return False, "مش مسجل"

    # تحقق من صلاحية الاشتراك
    if not is_plan_valid(user_id):
        return False, "انتهى اشتراكك ❌\n\nاشترك من جديد عبر /plans"

    plan_key = user["plan"]
    plan = PLANS.get(plan_key, PLANS["free"])
    limit = plan["limit"]

    if limit == -1:
        return True, ""  # غير محدود

    # تحقق من العداد اليومي
    today = datetime.now().strftime("%Y-%m-%d")
    last_reset = user.get("last_reset", "")
    daily_count = user.get("daily_count", 0)

    if last_reset != today:
        # يوم جديد - صفّر العداد
        conn = sqlite3.connect(DB_FILE)
        conn.execute("UPDATE subscriptions SET daily_count=0, last_reset=? WHERE user_id=?", (today, user_id))
        conn.commit()
        conn.close()
        daily_count = 0

    if daily_count >= limit:
        return False, (
            f"⚠️ وصلت للحد اليومي ({limit} طلب)\n\n"
            f"⬆️ رفّع باقتك عبر /plans للحصول على المزيد!"
        )

    return True, ""


def increment_usage(user_id: int):
    today = datetime.now().strftime("%Y-%m-%d")
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT last_reset, daily_count FROM subscriptions WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row:
        last_reset, daily_count = row
        if last_reset != today:
            daily_count = 0
        c.execute(
            "UPDATE subscriptions SET daily_count=?, last_reset=? WHERE user_id=?",
            (daily_count + 1, today, user_id)
        )
    conn.commit()
    conn.close()


def can_use_feature(user_id: int, feature: str) -> bool:
    user = get_user(user_id)
    if not user:
        return False
    plan_key = user["plan"] if is_plan_valid(user_id) else "free"
    allowed = PLANS.get(plan_key, PLANS["free"])["allowed_features"]
    return feature in allowed


def get_all_users():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT user_id, username, plan, expiry, daily_count FROM subscriptions ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return rows


init_db()
