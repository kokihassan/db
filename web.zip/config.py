# ============================================================
#  WebScrapper Bot - لوحة التحكم الرئيسية
#  عدّل أي حاجة هنا وأعد تشغيل البوت
# ============================================================

# ==================== معلومات البوت ====================
BOT_NAME = "WebScrapper Bot"
BOT_USERNAME = "@WebScrapperBot"
SUPPORT_USERNAME = "@YourSupportUsername"   # ← غيّر ده

# ==================== رسالة الترحيب ====================
START_TEXT = """
👋 أهلاً بك في **WebScrapper Bot**!

🕷️ أنا بوت متخصص في استخراج البيانات من المواقع.

📌 **ما أقدر أعمله:**
• استخراج الروابط والصور والفيديوهات
• استخراج الصوت والـ PDF
• تصوير الشاشة وتسجيل الفيديو
• استخراج الكوكيز والـ Metadata
• زحف الموقع كامل

💡 **طريقة الاستخدام:**
فقط أرسل لي أي رابط وأنا هتكفل بالباقي!

📦 اكتب /plans لتعرف الباقات المتاحة
📞 اكتب /contact للتواصل مع الدعم
"""

# ==================== زر التواصل ====================
CONTACT_TEXT = """
📞 **تواصل مع الدعم الفني**

👨‍💻 **المطور:** {support}
🕐 **وقت الاستجابة:** خلال 24 ساعة
📧 **للشراكات والاستفسارات التجارية راسلنا مباشرة**

⚡ نحن هنا لمساعدتك!
""".format(support=SUPPORT_USERNAME)

# ==================== الباقات ====================
# limit = -1 يعني غير محدود
PLANS = {
    "free": {
        "name": "🆓 المجاني",
        "price": 0,
        "currency": "USD",
        "period": "شهري",
        "limit": 10,           # عدد الطلبات في اليوم
        "features": [
            "✅ استخراج الروابط",
            "✅ استخراج الفقرات",
            "✅ استخراج الصور (حتى 10)",
            "❌ الصوت والفيديو",
            "❌ تصوير الشاشة",
            "❌ زحف الموقع",
        ],
        "allowed_features": ["rawData", "htmlData", "allLinks", "allParagraphs", "allImages"],
    },
    "basic": {
        "name": "⭐ الأساسي",
        "price": 9.99,
        "currency": "USD",
        "period": "شهري",
        "limit": 100,
        "features": [
            "✅ كل المميزات المجانية",
            "✅ استخراج الصوت والفيديو",
            "✅ استخراج الـ PDF",
            "✅ الـ Metadata والكوكيز",
            "❌ تصوير الشاشة",
            "❌ زحف الموقع الكامل",
        ],
        "allowed_features": ["rawData", "htmlData", "allLinks", "allParagraphs", "allImages",
                             "allAudio", "allVideo", "allPdf", "metadata", "cookies", "localStorage"],
    },
    "pro": {
        "name": "🚀 الاحترافي",
        "price": 24.99,
        "currency": "USD",
        "period": "شهري",
        "limit": -1,
        "features": [
            "✅ كل المميزات الأساسية",
            "✅ تصوير الشاشة",
            "✅ تسجيل الشاشة فيديو",
            "✅ زحف الموقع الكامل",
            "✅ طلبات غير محدودة",
            "✅ أولوية في الدعم",
        ],
        "allowed_features": ["rawData", "htmlData", "allLinks", "allParagraphs", "allImages",
                             "allAudio", "allVideo", "allPdf", "metadata", "cookies", "localStorage",
                             "screenshot", "screenRecord", "crawlWeb"],
    },
}

# ==================== تفعيل / تعطيل المميزات ====================
FEATURES = {
    "rawData":       True,
    "htmlData":      True,
    "allLinks":      True,
    "allParagraphs": True,
    "allImages":     True,
    "allAudio":      True,
    "allVideo":      True,
    "allPdf":        True,
    "cookies":       True,
    "localStorage":  True,
    "metadata":      True,
    "screenshot":    True,   # ← تم التفعيل
    "screenRecord":  True,   # ← تم التفعيل
    "crawlWeb":      True,
}

# ==================== إعدادات أخرى ====================
FINISHED_PROGRESS_STR = "▓"
UN_FINISHED_PROGRESS_STR = "░"
REPO = "https://github.com/nuhmanpk/WebScrapper/"

# المشرفون (يملكون صلاحيات كاملة بغض النظر عن الاشتراك)
# ضع الـ user_id بتاعك هنا
ADMINS = [123456789]   # ← غيّر ده لـ ID بتاعك
